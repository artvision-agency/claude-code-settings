---
name: LLM Wiki / Knowledge Architecture (Karpathy/Huryn)
description: Karpathy LLM Wiki — концепция зафиксирована, реализация частичная (каркас wiki/, остальное отсутствует)
type: reference
source: https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f
fetched: 2026-04-04
verified: 2026-04-17
originSessionId: 270c0fb8-4dee-4b64-9639-ba10bd1cac69
---
**Источник:** Karpathy @karpathy (2026-04-04), Pawel Huryn @PawelHuryn (Product Compass)
**Gist:** gist.github.com/karpathy/442a6bf555914893e9891c11519de94f

**Суть:** Вместо RAG (переоткрывание знаний каждый раз) — LLM строит и поддерживает persistent wiki. Три слоя: raw sources → wiki → schema.

## Реальное состояние (verified 2026-04-17)

| Компонент | Karpathy | Наша реализация | Статус |
|-----------|----------|-----------------|:------:|
| Wiki каркас | Persistent md с кросс-ссылками | `artvision-data/wiki/` (index.md, log.md, overview.md) | ✅ |
| Raw sources | Неизменяемые документы | `artvision-data/raw/` | ❌ нет папки |
| Schema | Конфиг | `~/.claude/rules/knowledge-system.md` | ❌ нет файла |
| Knowledge domains | Тематические папки | `artvision-data/knowledge/` | ❌ пусто |
| Decision journal | Structured decisions | `artvision-data/decisions/` | ❌ пусто |
| Quality gates | Self-evolving criteria | `artvision-data/quality/criteria.md` | ❌ нет папки |
| Ingest/Query/Lint | Ops-скрипты | `scripts/wiki-ops.py` | ❌ нет скрипта |
| Idea files | Абстрактные идеи | `artvision-data/ideas/` + TEMPLATE.md | ❌ нет папки |

## Вывод

**Karpathy wiki не внедрён.** Каркас `wiki/` создан 2026-04-06, но ingest/query/lint, decisions, quality, knowledge domains, raw sources — не запущены. Предыдущая memory заявляла "полную реализацию" — неверно.

**Реально работает вместо wiki:**
- Правила — `~/.claude/rules/*.md` (30+ файлов, auto-load)
- Память — `memory/*.md` (100+ trend/feedback/project)
- Skills — `~/.claude/skills/` (80+)
- Hooks — `~/.claude/hooks/` (11 хуков, factcheck/context-log)

**Когда вернуться к Karpathy-подходу:** если появится ощутимая потеря знаний между сессиями (задачи повторяются, агенты не знают контекст). Пока `rules/ + memory/ + skills/` покрывают задачу.

**Hypothesis lifecycle (полезная идея, не внедрена):** Наблюдение → hypotheses.md (UNTESTED) → 3x confirmed → rules.md (ENFORCE) → contradicted → RE-TEST.
