---
name: trend_claude_code_best_practices
description: Anthropic best practices Claude Code — verification first, short CLAUDE.md, hooks > prompts, fan-out patterns
type: reference
source: https://simonwillison.net/2026/Apr/9/claude-code-best-practices/
fetched: 2026-04-17T08:10:00Z
fetched_via: link-processor (skill process-link)
author: Anthropic (через Simon Willison)
confirmed_by:
  - https://docs.anthropic.com/claude-code/
---

## Факт
6 ключевых паттернов от Anthropic для работы с Claude Code:
1. Verification first (тесты/скриншоты перед кодом)
2. Explore → Plan → Code → Commit как фазовая последовательность
3. CLAUDE.md короткий (раздутый игнорируется)
4. Hooks важнее CLAUDE.md (детерминистичны)
5. Субагенты для исследования (разгрузка основного контекста)
6. Fan-out: `claude -p` в цикле для batch-операций

## Применимость
- **auto_mode** (products): Classifier на Sonnet 4.6 под Max план
- **seo_pipeline**: fan-out pattern для параллельных аудитов
- **page_pipeline**: Writer/Reviewer split для КП
- **claude_md_audit**: проверить наши CLAUDE.md на раздутость
- **hooks_validation**: подтверждает текущий hooks-first подход

## Проверено
2026-04-17, 2 источника (simonwillison.net, docs.anthropic.com)
