# Активные задачи и статусы (обновлено 2026-03-21)

Claude ОБЯЗАН прочитать этот файл при старте. Детали в PROJECTS.md.

## Открытые задачи

| Задача | Клиент/Продукт | Статус | Блокер |
|--------|----------------|--------|--------|
| Card Duel: Adsgram + GameAnalytics + submit | Card Duel | Код готов, нужна регистрация | — |
| Card Duel: Telegram Stars IAP + Battle Pass | Card Duel | Не начато | — |
| Esenina: продолжить по PLAN_v2.md | Esenina | Hero v5 готов | — |
| BluMart: КП для Юрия Хаита | BluMart | Factcheck пройден, правки | — |
| UNO Trans: финализация КП | UNO Trans | v4 готово, позиции через Topvisor | — |
| Mirulidi: базовый SEO-аудит для договора | Mirulidi | v2 подготовлен | — |
| OTIDO: РСЯ не работает с 12.03 | OTIDO | Диагностика: баланс 0 | Пополнение баланса |
| Extru: перевод на платный (долг 100K) | Extru | Roadmap готов, аргументы | — |
| AI Advisor: деплой фиксов на VPS | Бот | Баги исправлены | Нужен деплой |
| PolyTrends Bot: имплементация | Продукт | План 12 задач готов | — |
| artvision.pro: линкбилдинг план | Инфра | План в работе | — |
| GEO-аудит: шаблон услуги | AIvision | 6 клиентов проаудировано | — |
| Artssistant: холодный outreach | Продукт | 20 лидов собраны | — |
| Евразия Max-бот: BOT_TOKEN | Presale | MVP + 46 тестов готовы | Ждём токен от Макса |

## Недавно завершённые (март 2026)

| Задача | Дата | Результат |
|--------|------|-----------|
| Card Duel revenue toolbox + ACTION-MAP | 21.03 | Pipeline от кода до денег |
| UNO Trans Direct vs SEO forecast | 21.03 | 50 кластеров |
| BluMart КП factcheck + правки | 21.03 | 7 WRONG items fixed |
| Roman Mebel КП переработка | 21.03 | 12 стандартов, фото с сайтов |
| UNO Trans КП v3-v4 | 19-21.03 | SVG charts, SERM, content analysis |
| Yandex Webmaster region workflow | 19.03 | Playwright + GitHub Secrets |
| SEO-аудит Mirulidi v2 | 19.03 | Базовый аудит для договора |
| GEO-аудит 6 клиентов в AI | 19.03 | Видимость в AI-поисковиках |
| 6 SOP документов | 18.03 | Finance, PPC, Dev, PBN, Call, Comms |
| artvision.pro перегенерация + контент | 17.03 | 113 стр, 1500+ слов, 30 нишевых |
| CRO-аудит artvision.pro | 18.03 | 5 страниц, 7 измерений |
| Linkbuilding план artvision.pro | 18.03 | 4-week action plan |
| Artssistant лендинг + КП + лиды | 18.03 | 20 автосервисов СПб+МСК |
| PolyTrends Bot дизайн-документ | 18.03 | Plan ready |
| AI Advisor critical/high bugs | 18.03 | Все исправлены |
