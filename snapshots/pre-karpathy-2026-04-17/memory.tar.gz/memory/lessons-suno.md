# Suno Browser Automation — Lessons Learned

## Updated: 2026-03-02 (session 2)

## Credentials
- **Account**: antonkameristyi976
- **Plan**: Premier
- **Credits**: ~9701 (as of 2026-03-02 session 2)
- **Login**: через Google (justtrance@gmail.com)

## Ключевые URL
- Create: `https://suno.com/create`
- Library: `https://suno.com/me`
- Studio: `https://suno.com/studio`
- Track: `https://suno.com/song/<id>`

## Режимы создания (вкладки на /create)
1. **Simple** — быстрая генерация по описанию
2. **Custom** — полный контроль: Audio + Persona + Inspo
3. **Sounds** — звуковые эффекты

## Audio субвкладки (в Custom режиме)
- **Remix** — ремикс существующего трека
- **Inspo** — вдохновение из трека
- **Mashup** — объединение 2 аудиотреков (КЛЮЧЕВОЙ для напетых мелодий)
- **Sample** — семплирование

## КРИТИЧЕСКИ ВАЖНО: Текст vs Аудио

### Ошибка (НЕ повторять):
Писать "(tu-tu-tu-tu-tu)" в Lyrics для передачи мелодии — это НЕ работает.
Suno интерпретирует текст как слова для вокала, а не как ноты.

### Правильный подход:
Если пользователь **напел мелодию** → использовать **Mashup** или **Remix** с аудиофайлом.
Напетый файл содержит НОТЫ и их ВЫСОТЫ — текстом это не передать.

### Workflow для напетой мелодии:
1. Загрузить напев на Suno (Upload)
2. Перейти в Create → Custom → Audio → **Mashup**
3. Добавить оригинальный трек (Song 1)
4. Нажать "Add another song to Mashup"
5. В модальном окне найти Upload-трек с напевом
6. Выбрать "Keep Current Lyrics" (напев = инструментальный)
7. Задать стили (жанр, инструменты, темп)
8. Create → 2 варианта генерируются

## Навигация по Suno UI (Playwright MCP)

### Проблема: Click timeouts
Многие кнопки Suno не кликаются через Playwright ref-based click из-за:
- Overlay элементов
- React-портальные модалки
- Динамическая подгрузка

### Решение: JavaScript evaluate
```javascript
// Всегда использовать evaluate для кликов:
const btn = document.querySelector('button[aria-label*="текст"]');
btn.scrollIntoView({ block: 'center' });
btn.click();
```

### Проблема: React input value setting
`input.value = "text"` НЕ обновляет React state.

### Решение: Native setter + events
```javascript
const setter = Object.getOwnPropertyDescriptor(
  window.HTMLTextAreaElement.prototype, 'value'
).set;
setter.call(textarea, 'new value');
textarea.dispatchEvent(new Event('input', { bubbles: true }));
textarea.dispatchEvent(new Event('change', { bubbles: true }));
```

### Проблема: Поиск в модальных окнах
Search input в модальном окне "Add a song to mashup" плохо работает через JS.

### Решение: Перебор кнопок Select (ВАЖНО: dialog[1])
На странице Suno может быть **2 диалога одновременно**:
- `dialog[0]` — "You must be a Pro or Premier subscriber..." (1 кнопка, пустой)
- `dialog[1]` — "Add a song to mashup" (реальный контент с треками)

**ВСЕГДА использовать `querySelectorAll('[role="dialog"]')[1]`**, не `querySelector`.

```javascript
const dialog = document.querySelectorAll('[role="dialog"]')[1];
const selectBtns = [...dialog.querySelectorAll('button')]
  .filter(b => b.textContent.trim() === 'Select');

// Найти нужный трек по контексту родительских элементов
for (const btn of selectBtns) {
  let p = btn;
  for (let i = 0; i < 15; i++) {
    p = p.parentElement;
    if (!p) break;
    if (p.textContent.includes('IMG_5988')) {
      btn.click();
      break;
    }
  }
}
```

### Модальное окно фильтров
- Фильтры "(3)" могут скрывать Upload-треки
- Upload-тип виден даже с фильтрами, но нужно скроллить список
- Лучше искать по описанию "Upload" а не по названию файла

### Навигация к Mashup (полный путь)
1. Custom → кнопка "Audio" (+ Audio) → popup: Remix | Upload | Record
2. Кликнуть **Remix** → модал "Choose a song to Remix"
3. Tab **Library** → найти основной трек → Remix
4. Трек загрузится в Remix режиме, появятся вкладки: **Remix | Inspo | Mashup | Sample**
5. Кликнуть **Mashup** → Song 1 уже на месте
6. "Add another song to Mashup" → модал с Library → Select второй трек
7. "Keep Current Lyrics" если второй трек инструментальный

## Chrome for Testing — стабильность

### Частые дисконнекты
Chrome for Testing теряет связь с Playwright при:
- Долгом простое (>5 мин)
- Переключении вкладок системой
- Тяжёлых страницах Suno

### Восстановление
```bash
pkill -9 -f "Chrome for Testing"
rm -f ~/Library/Application\ Support/Google/Chrome\ for\ Testing/SingletonLock
rm -f ~/Library/Application\ Support/Google/Chrome\ for\ Testing/SingletonSocket
rm -f ~/Library/Application\ Support/Google/Chrome\ for\ Testing/SingletonCookie
sleep 3
# Playwright переподключится при следующем вызове
```

### Предотвращение
- Не держать пустые вкладки (about:blank)
- Делать периодические snapshot для поддержания связи
- Сохранять прогресс после каждого шага

## Suno: стоимость операций
- **Create** (обычная генерация): ~5 credits за 2 варианта
- **Extend**: ~5 credits за 2 варианта (30-60 сек каждый)
- **Mashup**: ~8 credits за 2 варианта (Mashup с Upload дороже обычного)
- **Cover**: ~5 credits за 2 варианта

## Структура песни: Talk Dirty to Me стиль
```
Verse (рэп) → Buildup → [Instrumental Drop] (труба, без слов) → Verse → [Instrumental Drop] → Outro

В lyrics маркер [Instrumental Drop] = Suno убирает вокал, оставляет инструмент.
Длительность варьируется: Suno может сделать 1:29 или 4:43 из одного промпта.
```

## Pipeline создания песни с напетой мелодией
1. Upload напева на Suno
2. Создать базовый трек (Simple/Custom)
3. **Mashup** базового трека с напевом → получить трек с реальной мелодией
4. **Extend** Mashup-результата до нужной длительности
5. Прослушать, выбрать лучший вариант
6. **Publish** если готов к релизу

## Текущие треки (сессия 2026-03-02)

### Оригиналы
- Original hip-hop (0:45): `6e075c1c-ecfd-478b-83e4-728000789b99`
- Old hummed melody Upload (0:18): `9066a6b0-2aa4-437c-acfe-cd551fe30036`
- NEW trumpet melody Upload (0:09): `f42e683a-d178-4ffe-84b8-5c3b885cdf95` (IMG_5988.mp3)

### Mashup v1 (old melody)
- Mashup 1 (0:38): `3e7589d2-75e1-4d9a-b536-a0f364de50ad`
- Mashup 2 "A&K - Bull it" (0:47): `e206bf80-b074-42a1-8a8f-52e78cfeef87`

### Mashup v2 — Trumpet Drop Mix (Bull it + IMG_5988)
- **#1 (4:43)**: `0a0178ed-ac6a-463b-9043-2052f7eb74f4` ← ПОЛНАЯ ПЕСНЯ
- #2 (1:47): `5c1d6150-0526-4ab4-a1ff-cd8a5395d6ed`
- #3 (1:39): `61051409-92f1-423c-b351-1832e5241ffc`
- #4 (1:29): `1af37b5e-8ffa-4396-b25f-9b6273b8581f`

## Дистрибуция
- **YOGA** — бесплатный дистрибьютор (поддерживает множество площадок)
- Можно создавать несколько артистических профилей
- Модерация занимает несколько дней
- Заявка подана 2026-03-02, ожидает модерации
