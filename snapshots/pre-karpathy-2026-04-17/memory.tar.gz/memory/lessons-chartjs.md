---
name: Chart.js canvas container pattern
description: Chart.js с maintainAspectRatio:false требует position:relative контейнер, иначе canvas расширяется бесконечно
type: feedback
---

Chart.js canvas с `maintainAspectRatio: false` ОБЯЗАТЕЛЬНО оборачивать в контейнер:
```html
<div style="position:relative;width:100%;height:280px;">
  <canvas id="my-chart"></canvas>
</div>
```

**Why:** Без контейнера Chart.js игнорирует `style="height:280px"` на canvas и рассчитывает высоту из aspect ratio → canvas растёт до 6000+ px. CSS класс с `height` тоже не помогает. Инцидент: МирБир dashboard, 3 графика в "Контроль бизнеса" рендерились 6922px вместо 280px (2026-04-06).

**How to apply:** При создании/ревью любого HTML с Chart.js — проверять что ВСЕ canvas элементы с `maintainAspectRatio: false` обёрнуты в `position:relative` div с явной высотой. Массовая проверка: `/validate-pages` → Canvas/Chart Overflow check.
