---
name: Atribeaute outreach — ждём понедельник
description: КП готово, НЕ отправлять Галине до подтверждения Антона в понедельник 2026-03-23
type: project
---

КП-пакет для возвращения Atribeaute готов и задеплоен:
- КП: artvision.pro/kp/atribeaute/return-package.html
- Content Lab: artvision.pro/kp/atribeaute/content-lab.html

**Why:** Антон сказал "dont send until asking on monday" — клиент на паузе, контакт ТОЛЬКО с подтверждения.

**How to apply:** В понедельник 2026-03-23 спросить Антона: "Отправляем КП Галине (Atribeaute)?" Без ОК — не отправлять.
