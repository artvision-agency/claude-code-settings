---
name: feedback_deploy_urls
description: ВСЕГДА давать полные кликабельные URL при показе деплой-ссылок
type: feedback
---

Деплой ссылки — ВСЕГДА полный кликабельный URL (https://...), не сокращённый путь.

**Why:** Антон хочет кликнуть и сразу открыть в браузере. Путь без https:// не кликается.

**How to apply:** При любом упоминании тестового/боевого URL — полный формат: `https://artvision.pro/esenina/`, `https://artvision.pro/ant-test/` и т.д.
