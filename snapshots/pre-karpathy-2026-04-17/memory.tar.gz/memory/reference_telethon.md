---
name: reference_telethon
description: Telethon MTProto session for reading TG chats — auth, API keys, scripts, chat IDs
type: reference
---

## Telethon — доступ к TG чатам

**Session:** `/Users/antonk/.claude/state/telethon_session`
**API ID:** 35195969
**API Hash:** `576ad787126be6f43f28df1a1279aa4a`
**Auth:** Anton Kameristyi (@AntonKamer), phone +79819139908

### Скрипт экспорта чатов
`~/.claude/scripts/tg-chat-export.py`

```bash
# Поиск чатов по имени
python3 ~/.claude/scripts/tg-chat-export.py --search "Екатерина"

# Экспорт чата в файл
python3 ~/.claude/scripts/tg-chat-export.py --chat-id 954855520 -o output.md

# Список всех диалогов
python3 ~/.claude/scripts/tg-chat-export.py --list

# Фильтр по дате
python3 ~/.claude/scripts/tg-chat-export.py --chat-id 954855520 --since 2026-03-01
```

### Известные чаты клиентов
- **Esenina группа:** -5134497082 ("Ведущая Е Есенина / Мероприятия (AV.pro)")
- **Esenina личка:** 954855520 ("Екатерина Есенина")
- **Екатерина Романюк:** 8337657082

### Важно
- Сессия может истечь — при ошибке auth нужен новый код из TG
- Telethon читает ВСЮ историю чата, независимо от даты добавления бота
- Не путать с Bot API — Telethon = userbot (MTProto), полный доступ
