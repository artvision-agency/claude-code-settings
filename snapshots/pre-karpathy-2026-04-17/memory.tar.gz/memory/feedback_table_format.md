---
name: feedback_table_format
description: Always display task results, status updates, and progress as tables with checkmarks/status marks, never as plain lists
type: feedback
---

Всегда показывать задачи, результаты и прогресс **таблицей** с отметками (✅/❌/⏳/🔴 и т.д.), а не списком.

**Why:** Антон явно попросил "всегда показывай таблицей с отметками готово нет и тд" — ему важна визуальная структура и быстрое считывание статуса.

**How to apply:** При любом выводе задач, результатов работы, статусов проектов — использовать markdown-таблицу с колонками: №, Задача, Статус, Детали. Статус — иконками (✅ ❌ ⏳ 🔴 🟡 🟢).
