---
name: Маркетинг-дайджест — naming + per-article publishing
description: Жёсткие правила публикации новостей на artvision.pro — название "Маркетинг-дайджест", своя страница на каждую новость, наш рерайт. Без AI/нейросетей/LLM в публичных текстах
type: feedback
originSessionId: 1b023743-3bb1-47f3-971d-2c8909768ca1
---
**Правило:** новостные публикации на artvision.pro = **«Маркетинг-дайджест»**, каждая новость = отдельная страница (250-350 слов рерайта через Groq), Telegram даёт ссылки на наши URL.

**Why:** Антон поймал три нарушения подряд (2026-04-13):
1. Название "AI-дайджест" в публичном заголовке — нарушает табу AI/нейросети в публичных материалах (rules/security.md).
2. Бандл-лист из 5-10 новостей в одном посте — пользователи кликают на источник и уходят с сайта.
3. Нет своих копий → нечего ранжировать в Google, нет SEO-эффекта от трафика.

**How to apply:**
- Скрипт публикации: `/root/scripts/marketing_digest_vps.py` (источник: `artvision-data/scripts/marketing_digest_vps.py`). Использует Groq `llama-3.3-70b-versatile`, токен в `tokens.artvision_pro.wordpress` + `tokens.groq.api_key`.
- Slug: `marketing-digest-{YYYY-MM-DD}-{title-slug}` через русскую транслитерацию.
- В рерайте ЗАПРЕЩЕНЫ: AI, нейросеть, ИИ, искусственный интеллект, машинное обучение, LLM, Claude, GPT, ML. System prompt + sanity scrub.
- Источник внизу: `<p><em>Подробности у источника: <a href="...">{source}</a></em></p>`. Никаких редиректов из тела.
- Telegram-дайджест ссылается ТОЛЬКО на наши `artvision.pro/news/marketing-digest-...` URL.
- Cron VPS: 06/11/16 UTC, лог `/var/log/marketing-digest.log`. Дедуп `/root/scripts/.digest_seen.json`.
- Старый `ai_digest_vps.py` отключён, 23 поста с "AI-дайджест" удалены через WP REST API (2026-04-13).
- Skill `ai-news-monitor` обновлён: жёсткие правила вынесены в начало SKILL.md.
