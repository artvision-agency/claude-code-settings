---
name: njus.extru-tech@mail.ru — клиентская, не Artvision
description: njus.extru-tech@mail.ru принадлежит клиенту Extru, НИКОГДА не ассоциировать с Artvision/доменом artvision.pro
type: feedback
originSessionId: 91357ab0-1c4c-4a07-9f0a-99a2b6e7997a
---
`njus.extru-tech@mail.ru` = почта **заказчика extru-tech-tpk** (клиент Extru, сайт extru-tech-tpk.ru). НЕ Artvision.

**Why:** 2026-04-03 при регистрации домена artvision.pro в VK WorkSpace по ошибке использовали этот клиентский VK ID. Антон явно сказал забыть её как часть Artvision навсегда (2026-04-13).

**How to apply:**
- Никогда не упоминать в контексте Artvision, tokens.json.vk_workspace, почты anton@/boss@artvision.pro
- Админ-аккаунт VK WorkSpace для artvision.pro = `artvision.pro@mail.ru` (и только он)
- Если встречается в логах/сессиях — игнорировать как артефакт ошибочной регистрации
