# Frontend / HTML — уроки

## Справочник: Front-End-Checklist (2026-03-02)
**Репо:** `/Users/antonk/Front-End-Checklist/README.md`
**Когда:** при генерации/аудите ЛЮБЫХ клиентских HTML.

### Обязательные проверки (HIGH priority):
- DOCTYPE, charset, viewport (+ `viewport-fit=cover`), title (<55 символов), description (<160)
- `<link rel="canonical">`, favicon, `lang="ru"` на `<html>`
- `target="_blank"` → `rel="noopener noreferrer"` ОБЯЗАТЕЛЬНО
- `<img>` → `alt`, `width`, `height`, `loading="lazy"`
- H1 один на страницу, иерархия H1→H2→H3 без пропусков
- JSON-LD Schema.org → **ОТДЕЛЬНЫЕ `<script>` теги** для каждого объекта
- OG теги: `og:image:width`, `og:image:height`

### Аудит ANT Partners 2026-03-02 (ошибки → фиксы):
1. Два JSON-объекта в одном script = невалидный JSON → разделил на 2 script тега
2. Нет canonical → добавлен в шаблон
3. H2→H4 пропуск → нужно исправить в JSON-данных
4. description >160 символов на 6 страницах
5. **Критично:** bankrotstvo.json — сумма 300К вместо 2М руб (устарело ФЗ-107 от 29.05.2024)

---

### ПЕРЕД деплоем — ВСЕГДА проверяй инфраструктуру (2026-03-11)
**Инцидент:** сгенерировал standalone HTML, задеплоил в `/var/www/`, запустил 3 агента ревью — а сайт на WordPress. Standalone HTML перехватывался nginx, не наследовал тему. Потерял ~$1.50 на агентов и 30 мин.

**Правило:** ДО генерации/деплоя контента на сайт клиента:
1. Проверить CMS (WordPress? Tilda? Статика?)
2. Проверить существующие страницы (`wp-cli post list`, WP REST API)
3. Если WP → обновлять через `wp-cli post update` или WP REST API
4. Standalone HTML → только для тестовых/отчётных страниц (reports.artvision.pro)
5. **artvision.pro = WordPress + nginx**, статические файлы в `/var/www/` перехватывают WP routing

### Перелинковка — проверять не только внутри статьи (2026-03-11)
Перелинковка между страницами услуг И статьями блога. Статья должна ссылаться на услуги, услуги — на статьи. Не только footer/TOC — контекстные ссылки внутри контента.

### Валидация HTML = DOM-парсинг, НЕ grep (2026-02-10)
grep считает строковые совпадения включая CSS. Скрипт: `scripts/validate_wave1_dom.py` (BeautifulSoup).

### Попапы/модалки — скилл popup-cro (2026-02-23)
CSS `:target` для попапов = хрупкий паттерн (конфликт с smooth scroll). Правильно: JS classList.toggle.

### КП/Презентации — извлекать дизайн-систему клиента (2026-02-09)
СНАЧАЛА парсить сайт на цвета/шрифты. Ошибка: КП DemosMed в cyan/purple вместо бренда.

### Шаблон CAMEO KP — эталон для fashion/lifestyle + e-commerce (2026-03-11)
**Файл:** `clients/kamey/presale/kp/cameo_kp.html`
**URL:** `https://artvision.pro/kp/cameo/`
**Почему хорош:** дизайн-система извлечена из kamey.ru, стильная подача, карточный аудит с анимированными барами, таблица цен с данными 18 агентств, маркетплейс-специфичные секции. Использовать как базовый шаблон для КП в нишах fashion/lifestyle/e-commerce/маркетплейсы.
**Для artvision.pro:** Дизайн CAMEO (тёмный аудит + карточки + wow-эффекты) — приберечь как референс для обновления дизайна artvision.pro. Конкретно: audit-card layout, market-price table, counter animations, typewriter hero.

### IntersectionObserver + display:none = ЛОМАЕТСЯ (2026-04-04)
**Проблема:** анимация карточек через IntersectionObserver (opacity 0→1) не работает когда родительская секция `display:none`. Observer ставит opacity:0, но никогда не переключает на 1 — потому что элемент невидим для IO пока parent скрыт.
**Решение:** MutationObserver на атрибут `class` родительской секции:
```javascript
var observer = new MutationObserver(function(mutations) {
  mutations.forEach(function(m) {
    if (m.target.classList.contains('active')) { animateCards(); }
  });
});
observer.observe(sectionEl, { attributes: true, attributeFilter: ['class'] });
```
**Правило:** для SPA с tab-переключением (display:none/block) — ВСЕГДА MutationObserver, НИКОГДА IntersectionObserver для анимаций.

### CSS дедупликация в scoped sections (2026-04-04)
При мерже нескольких standalone HTML-файлов в один — CSS дублируется (в `<style>` head и inline `<style>` в секции). Безопасно удалять копию из head если inline `<style>` в секции полностью автономен. Проверка: diff двух блоков, если идентичны — оставить только inline.

### Signal Filters паттерн — data-dirs + JS toggle (2026-04-04)
Для фильтрации карточек по категориям:
1. `data-dirs="pivo,vino"` на каждый элемент (CSV список тегов)
2. Кнопки-фильтры с `.signal-filter-btn.active` стилем
3. JS: `dirs.indexOf(dir) !== -1` → show/hide через CSS класс `.hidden-by-filter`
4. "Все" сбрасывает фильтр. Работает с CSS grid без пересчёта.

### Floating CTA — фиксированная кнопка (2026-04-04)
`position:fixed; bottom:24px; right:24px; z-index:9999;` + gradient background + box-shadow. На мобиле (<480px) уменьшить padding и шрифт. Создавать через JS `document.createElement` чтобы не дублировать в каждой секции.

### CSS nth-child перебивает классовые стили (2026-02-23)
`section:nth-child(even){background:...}` перебивает `.cta-section{background:...}` из-за shorthand `background` сбрасывающего `background-image` (градиент). Фикс: `!important` или более специфичный селектор.

### Скачивание HTML файлов — nginx Content-Disposition (2026-02-23)
Атрибут `download` в `<a>` не всегда работает (cross-origin). Надёжный способ: nginx location с `if ($arg_dl = "1") { add_header Content-Disposition "attachment"; }`. URL: `file.html?dl=1`.

### Inline аудио в HTML — OGG vs MP3 (2026-03-02)
**Проблема:** `<audio>` с `<source src="data:audio/ogg;base64,...">` не играет в Safari (iOS/macOS). OGG Opus не поддерживается Safari.
**Решение:** конвертировать OGG → MP3 через `ffmpeg -y -i file.ogg -codec:a libmp3lame -qscale:a 4 file.mp3`, затем заменить base64.
**Нюансы:**
- MP3 base64 в ~2.5x больше OGG → файл растёт (3.8 MB → 10 MB для 3 аудио)
- Для универсальной совместимости — MP3 единственный формат. Двойной source (OGG + MP3) = двойной размер, нет смысла для inline
- Python regex для замены: `re.sub(r'<source src="data:audio/ogg;base64,[A-Za-z0-9+/=]+"[^>]*>', ...)` — учитывать любые атрибуты после base64
- **Проверка:** `curl -sL -o /dev/null -w "%{http_code} %{size_download}"` проверяет только доставку, НЕ работу аудио. Для аудио нужен реальный браузер.

### Telegram URL-кнопки и Яндекс Карты (2026-03-08)
**Проблема:** `InlineKeyboardButton(url="https://yandex.ru/maps/org/.../")` — кнопка ничего не делает на некоторых клиентах Telegram (Desktop macOS). Яндекс Карты отдаёт `X-Frame-Options: DENY` → Telegram WebView не может открыть.
**Решение:** координатная ссылка `https://yandex.ru/maps/?ll=30.41,59.94&z=17&text=Название` — открывается надёжнее (прямой рендер карты, не SPA-роутинг организации).
**Альтернативы:** `bot.send_location(lat, lon)` — для максимальной надёжности, но теряется красивое оформление с кнопками.
**Правило:** для карточных URL в Telegram — ВСЕГДА координатная ссылка, НЕ `/org/` путь.

### WordPress + Tilda миграция — КРИТИЧЕСКИЕ уроки (2026-03-09)

**Проблема 1: `the_content()` уничтожает Tilda HTML**
WordPress фильтры (`wpautop`, `wp_kses`, `wptexturize`) разрушают сложный HTML:
- `<style>` блоки извлекаются из потока, `<div>` структуры ломаются
- 2.1MB контент в БД → только 1 из 284 блоков рендерится в DOM
- **Решение:** `readfile()` — подавать Tilda HTML как статические файлы, минуя WP content pipeline
- Шаблон: `page.php` маппит slug → файл в `tilda_pages/`, вызывает `readfile()`

**Проблема 2: Двойной URL при замене путей изображений**
Regex замена CDN URL → локальные пути может удвоить путь если атрибут (`data-original`) уже содержит частичную замену:
```
/tvorim-test/.../images/tvorim-test/.../images/tildXXX  ← ДВОЙНОЙ
```
- **Фикс:** после замены проверять `str.count(double_path)` и чистить
- **Профилактика:** сначала проверить `if theme_base not in value`, потом заменять

**Проблема 3: Файловые permissions после scp**
`scp` как root → файлы 600, директории 700 → nginx (worker) не может читать:
```bash
find /path/ -type f -exec chmod 644 {} +
find /path/ -type d -exec chmod 755 {} +
```
- **Обязательно** после любого `scp` на VPS для публичных файлов

**Проблема 4: nginx basic auth**
- `.htaccess` — ТОЛЬКО Apache. nginx его ПОЛНОСТЬЮ ИГНОРИРУЕТ
- nginx: `auth_basic` + `auth_basic_user_file` в `location` блоке
- Пароль: `openssl passwd -apr1` (MD5). НЕ bcrypt ($2y$) — nginx не поддерживает

**Проблема 5: WP CLI на VPS**
- Всегда `--allow-root` при работе из-под root
- `wp eval 'echo file_get_contents("/tmp/file");'` — для импорта больших HTML (>1MB) в post_content
- `--post_content=<{file}` — НЕ работает для больших файлов (хранит путь вместо содержимого)

**Архитектура Tilda-to-WP (рабочая):**
```
tilda_pages/*.html (чистый Tilda HTML, без WP обёрток)
  ↓ readfile() в page.php
  ↓ slug → файл маппинг
  ↓ tilda_assets/ (CSS, JS, images) с правильными permissions
```
