---
name: Voice Control for Claude Code
description: Выбранная архитектура голосового управления Claude Code — wake word + STT + алиасы
type: project
originSessionId: 8220ba0f-72ba-4953-8f8b-3d8038862265
---
# Голосовое управление Claude Code

## Решения (выбраны 2026-04-17)

**Wake word:** `эй клод` (не "клод" — 2 слога дают false positives на "клон/код")

**Стек (ТОП-1 из ресёрча):**
- Porcupine (Picovoice) — wake word detection локально
- Groq Whisper API — STT (8ч аудио/день бесплатно, large-v3, <1 сек latency)
- Python скрипт + LaunchAgent

## 3 уровня реализации

1. **Shell-алиасы** — `плод`, `flood`, `к`, `кк` → `claude` (30 сек)
2. **Голосовой демон** — Porcupine слушает "эй клод" → запускает Claude (~30 мин)
3. **Полный voice loop** — STT + TTS, hands-free работа с Claude Code

## Подводные камни

- Groq 20 RPM — debounce коротких фраз обязателен
- Porcupine требует access key (free, но регистрация в web-консоли)
- "эй клод" в Picovoice Console — кириллица/фонетика: проверить при реализации что поддерживается
- Альтернатива offline: openWakeWord + mlx-whisper (но требует ML-тренинг wake word)

## Why

Цель: hands-free взаимодействие с Claude Code, минимум касаний клавиатуры.

## How to apply

Когда Антон вернётся к теме voice control — использовать этот стек, не переисследовать.
Ресёрч бесплатных STT (2026-04-16): Groq лучший API, mlx-whisper лучший offline.
