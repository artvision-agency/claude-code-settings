---
name: reference_avportal_bot_runtime
description: @avportal_bot живёт на VPS через pm2 (grammY + polling), не на Vercel. Vercel next.js route.ts — legacy.
type: reference
fetched: 2026-04-17
originSessionId: 57fa2d1d-69ca-4bc4-b898-9da2ce919020
---
## Где реально бежит @avportal_bot

**Production runtime:**
- Host: VPS 80.90.181.152 (`ssh cmd`)
- Path: `/root/artvision-tg-bot/vps-bot/bot.js`
- Framework: **grammY** (ES modules, Node 22)
- Mode: **polling** (long-poll Telegram, не webhook)
- pm2 process: `avportal-bot` v6.0
- Token: тот же `TELEGRAM_BOT_TOKEN` что в `.env.local`

**Vercel Next.js (legacy):**
- URL: `https://artvision-tg-bot.vercel.app/api/telegram`
- File: `app/api/telegram/route.ts` в репо
- Webhook формально зарегистрирован у Telegram (`getWebhookInfo` его видит)
- НО: VDS-бот при старте **удаляет webhook** (`deleteWebhook`) и пуллит сам
- Поэтому Vercel-эндпоинт НЕ получает реальные сообщения

## Деплой любой новой фичи

1. Редактировать `vps-bot/bot.js` (НЕ `app/api/telegram/route.ts`)
2. `git commit + push`
3. `ssh cmd "cd /root/artvision-tg-bot && git stash -u && git pull && pm2 restart avportal-bot"`

## Как это обнаружили

2026-04-17: тестировали link-inbox handler — код в Next.js деплоился Vercel'ом (HTTP 200 на webhook), но строки в Supabase не появлялись. Антон указал "у нас есть VDS". `ssh cmd "pm2 list"` → обнаружили `avportal-bot v6.0 uptime 7d`. Добавили handler в `vps-bot/bot.js`, после `git pull + pm2 restart` — заработало за ~5 секунд.

## Антипаттерн

Не добавлять handlers одновременно в оба места — получится race или путаница.
Для @avportal_bot — **ТОЛЬКО vps-bot/bot.js**.

## Связанные боты на VPS (pm2)

| Process | Файл | Назначение |
|---|---|---|
| `avportal-bot` | `vps-bot/bot.js` | @avportal_bot — AI Advisor, Asana, link inbox |
| `tvorims-bot` | `/opt/tvorims-bot/` | @tvorims_bot — отзывы, клиенты ТС |
| `tvorim-opros-bot` | `tvorim-opros-bot/` | Опросы пациентов |
| `otido-utm-bot` | `otido-utm-bot/` | UTM-инжектор для OTIDO канала |
| `stammit-bot` / `thai-ru-bot` / `travel-bot` | — | Прочие боты команды |

Все через `pm2 list` видны.
