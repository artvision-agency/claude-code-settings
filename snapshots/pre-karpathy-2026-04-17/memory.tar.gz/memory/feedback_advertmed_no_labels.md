---
name: advertmed_no_artvision_labels
description: Для AdvertMed (субподряд) НЕ использовать брендированные продукты Artvision в материалах
type: feedback
---

Все материалы для AdvertMed и их клиентов (Варикознет, Радуга Звуков и т.д.) — БЕЗ лейблов экосистемы Artvision.

**Запрещено:** Artvision Flow, Artvision Scout, Artvision Radar, Artvision LinkForge, Artvision Content Lab и т.д.
**Вместо этого:** "SEO-аудит", "мониторинг позиций", "анализ конкурентов", "контент-стратегия"

**Why:** AdvertMed — заказчик, мы субподрядчик. Наши внутренние бренды продуктов не нужны в их материалах — они продают от своего имени.

**How to apply:** При создании КП, отчётов, презентаций для AdvertMed и их клиентов — проверять отсутствие "Artvision [Product]" в тексте. Правило в `clients/advertmed-varikozanet/CLAUDE.md`.
