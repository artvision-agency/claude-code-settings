# Деплой КП — стандартный процесс

## URL-паттерн
```
https://artvision.pro/kp/[имя-проекта]/
```
Пример: `https://artvision.pro/kp/ortodental/`

## Шаги

1. **HTML** создаётся в `presales/[клиент]/kp/` → коммит в git
2. **SCP деплой** на VPS (80.90.181.152):
   - Credentials: `tokens.json → timeweb_cloud.vps`
   - Path: `/var/www/artvision/kp/[имя-проекта]/index.html`
3. **noindex** — `.htaccess` в `/kp/` (уже на месте на VPS)
4. **Ссылка клиенту** — `https://artvision.pro/kp/[имя-проекта]/`

## SCP-команды
```bash
# Создать директорию + загрузить
ssh root@80.90.181.152 "mkdir -p /var/www/artvision/kp/[project] && chown www-data:www-data /var/www/artvision/kp/[project]"
scp local.html root@80.90.181.152:/var/www/artvision/kp/[project]/index.html
ssh root@80.90.181.152 "chown www-data:www-data /var/www/artvision/kp/[project]/index.html"
```

## Контакты в КП
- Телефон: +7 (911) 086-18-88 (Антон)
- Telegram: @antonkamer
- Сайт: artvision.pro

## Хостинг artvision.pro
- **Timeweb Cloud VPS** (Amsterdam, NL)
- IP: 80.90.181.152
- SSH: root (пароль в tokens.json → timeweb_cloud.vps)
- nginx + PHP-FPM 8.3 + MariaDB
- SSL: Let's Encrypt (Certbot, auto-renew)
- DNS: reg.ru (ns1.reg.ru, ns2.reg.ru)

## История миграции (2026-02)
- **Было:** Timeweb Shared (`vh254.timeweb.ru`, IP 92.53.96.201, только FTP)
- **Стало:** Timeweb Cloud VPS (80.90.181.152, полный SSH)
- Shared можно отключать — DNS давно переключён

## Важно
- nginx `location /kp/` + `?dl=1` → Content-Disposition: attachment
- KP файлы в `/var/www/artvision/kp/` (lowercase!)
- Есть также `/var/www/artvision/KP/` (uppercase, legacy) — не использовать
- Все КП деплоятся по этому паттерну — СТАНДАРТНЫЙ процесс
