# Symmetron — перевод PDF datasheets — уроки

### JSON-парсер LLM-ответов — 4-стратегийный fallback (2026-02-12)
1. Strip markdown fences → json.loads
2. Найти outermost `{}` + убрать trailing commas
3. Truncation recovery: обрезать на последней запятой, закрыть `}`
4. Line-by-line salvage: regex
Параметры: batch_size=80, max_tokens=16000.

### PDF координаты: PyMuPDF vs ReportLab
PyMuPDF = top-left origin (y↓). ReportLab = bottom-left origin (y↑). Конверсия: `rl_y = page_height - pymupdf_y`

### Размер шрифта при наложении текста
Cap 18pt + binary search (12 итераций) вместо линейного -0.5 шага.

### Фильтры текста — не слишком агрессивные
regex `^\d+` убивал "3.3 V supply". Фильтровать только ЧИСТО числовые строки.

### PTSans шрифт захардкожен на macOS
На Linux VPS нужно скачать и указать другой путь.

### Кеширование переводов = экономия API
JSON кеш per document. Повторный прогон не тратит API.

### TOC dot-leader bug (2026-03-27)
**Проблема:** Table of Contents не переводился — FEATURES, GENERAL DESCRIPTION оставались на EN.
**Причина:** Фильтр `(.{4,})\1{2,}` ловил точки-заполнители как "мусор". PyMuPDF даёт TOC как цельные спаны: `"1. FEATURES.............5"`
**Фикс:** `re.sub(r'\.{3,}[\s\d]*$', '', text)` перед проверкой повторений + очистка dot leaders в `extract_translatable_text`. Порог аббревиатур ≤10 → ≤5.
**How to apply:** При добавлении skip-фильтров — тестировать на TOC-страницах.

### Инфра (актуально 2026-03-27)
- API: `https://artvision.pro/symmetron/api/upload`, header `X-API-Key`
- VPS venv: `.venv/` (не `venv/`)
- LLM: Claude Opus через OpenRouter → Anthropic fallback → CLI
- 83-стр PDF → ~6 мин (24 батча × 80 текстов)
