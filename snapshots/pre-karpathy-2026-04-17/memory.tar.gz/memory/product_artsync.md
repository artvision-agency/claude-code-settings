---
name: ArtSync — продукт анализа переговоров
description: ArtSync (ранее Sales Psychology / Artvision Insight) — аудио→транскрипция→анализ встреч. DISC-профилирование, summary, рекомендации.
type: project
---

**ArtSync** = анализ переговоров и встреч.

**Why:** Единый паттерн именования Art + [слово]. ArtSync = синхронизация с клиентом, понимание его психологии.

**How to apply:**
- Во всех материалах — "ArtSync", НЕ "Sales Psychology"
- Pipeline: audio→Whisper→Claude→summary+DISC
- Phase 0: на записях Варикознет
- Цель: 500K/мес
- Лендинг: artvision.pro/insight/ (переименовать в /artsync/)
