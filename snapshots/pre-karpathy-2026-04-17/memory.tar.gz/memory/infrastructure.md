# Инфраструктура Artvision (обновлено 2026-03-21)

## VPS — ОДИН сервер в Amsterdam
- **IP:** 80.90.181.152
- **Расположение:** Amsterdam, NL (Timeweb nl-1)
- **Конфигурация:** 4 CPU / 8 GB RAM / 80 GB NVMe / 100 Mbit
- **Цена:** 1210 ₽/мес
- **Timeweb ID:** 6670871, name: artvision-main-nl
- **Credentials:** tokens.json → timeweb_cloud.vps
- **AI API:** работают НАПРЯМУЮ (EU IP), никаких прокси/туннелей не нужно
- **Claude Code:** работает напрямую, credentials в `/root/.claude/.credentials.json`
- **OpenClaw:** установлен но ВЫКЛЮЧЕН (systemctl disabled)

## Что работает на VPS:
- **PM2:** avportal-bot, smm-publish-api, claude-dispatcher, vps-bot (AI Advisor)
- **nginx:** kb.artvision.pro, reports.artvision.pro, reports-ip, artvision.pro (основной)
- **cron:** git sync, SMM digest 4x/day, health check, log rotation
- **Claude Code** — Max подписка, напрямую без прокси
- **Card Duel VPS:** 147.45.232.226 :3001 (Colyseus Docker + Nginx) — отдельный сервер

## История миграции (2026-02-17):
- **Было:** Novosibirsk VPS (109.71.242.6, 1210₽) + NL proxy (72.56.118.75, 510₽) = 1720₽
- **Стало:** Один NL сервер (80.90.181.152, 1210₽) = экономия 510₽/мес
- Старые серверы УДАЛЕНЫ (twc server remove)
- WARP бесполезен для обхода геоблока (выходит через RU PoP, loc=RU)

## SSH / tmux troubleshooting (2026-02-28)
- `ssh vps` = RemoteCommand `tmux new-session -A -s artvision` + RequestTTY yes
- Если tmux сессия зависает → `ssh cmd` (без tmux) + `tmux kill-server` → пересоздастся
- "Connection closed by remote host" при SSH = почти всегда RemoteCommand упал (tmux/скрипт), а не SSH
- `ssh -vvv` покажет реальную ошибку (stderr от RemoteCommand)
- Brute-force на SSH замечен — проверить fail2ban

## VPS уроки
- devops-agent: НИКОГДА не хардкодить пути. `from env_detect import TOKENS_PATH`, НЕ хардкодить `/Users/antonk/...`
- Node.js НЕ подхватывает SOCKS5 → proxychains4
- PM2 cluster mode + dotenv: нужен явный `--cwd`
- twc CLI: `/Library/Frameworks/Python.framework/Versions/3.14/bin/twc`
