---
name: Screaming Frog обязателен для SEO
description: Screaming Frog SEO Spider установлен, CLI доступен — использовать для глубокого краула сайтов
type: feedback
---

Screaming Frog SEO Spider ОБЯЗАТЕЛЕН для сканирования сайтов при SEO-аудитах.

**Why:** Антон явно указал что SF подключен и должен использоваться. Глубокий краул важен для полного технического SEO.

**How to apply:**
- При SEO-аудите любого клиента — запускать SF краул через CLI
- Путь: `/Applications/Screaming Frog SEO Spider.app/Contents/MacOS/ScreamingFrogSEOSpiderLauncher`
- Headless режим: `--headless --crawl <url> --output-folder <path> --export-format csv --overwrite`
- Экспорт: `--export-tabs` для конкретных данных, `--bulk-export` для массового экспорта
- `--save-crawl` для сохранения краула
- `--create-sitemap` для генерации sitemap
- Результаты сохранять в `clients/[name]/seo/screaming-frog/`
- Интеграции доступны: Google Analytics 4, Search Console, PageSpeed, Majestic, Ahrefs
