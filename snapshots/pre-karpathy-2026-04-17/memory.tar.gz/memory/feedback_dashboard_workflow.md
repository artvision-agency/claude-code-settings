---
name: Dashboard workflow optimization
description: Presale dashboards take 8h instead of 1.5h due to data-last architecture. Data-first + URL validation + 1 dashboard per session = 4.8x speedup
type: feedback
---

Presale дашборды (МирБир кейс, 2026-04-01) заняли 8 часов вместо ~1.5ч. 71% времени = rework.

**Why:** Данные собирались ПОСЛЕ генерации HTML, URLs не валидировались до вставки, 3 файла по 100-300KB в одной сессии = compaction.

**How to apply:**
1. **Data-first**: собрать ВСЕ данные в `client-data.json` с маркировкой CONFIRMED/UNCONFIRMED → фактчекинг JSON → только потом рендеринг HTML
2. **URL-first**: `scripts/validate-urls.py` — curl -sI на каждый URL ДО вставки. Никаких generic/homepage URLs
3. **1 дашборд = 1 сессия**: не пихать 3 файла по 100-300KB в один контекст
4. **Шаблон**: `templates/dashboard-presale/template-mvp.html` — не писать с нуля каждый раз
5. **Batch deploy**: один `rsync` после финального factcheck, не 7 отдельных scp
6. **Чеклист до старта**: проверить домен (www vs non-www), токены API, counter ID, антибот на источниках

Автоматизация: `scripts/validate-urls.py`, `scripts/render-dashboard.py`, `templates/dashboard-presale/`
