---
name: HH-Leadgen (Artvision Leads)
description: Lead generation from hh.ru vacancies — parser, enrichment, scoring, outreach. API заявка #19675 на рассмотрении.
type: project
---

## Статус: MVP запущен (2026-04-04), API заявка отправлена (2026-04-06)

Парсер hh.ru вакансий для лидогенерации. Компания ищет маркетолога = есть бюджет и потребность = предлагаем аутсорс.

**Why:** Нулевая конкуренция в РФ (NBM-IT единственный аналог, reply 8%). LTV/CAC = 15.5x.

**How to apply:** Код в `products/hh-leadgen/`, стек Python 3.11+, SQLite (MVP), SQLAlchemy 2.0 async.

### API Registration (2026-04-06)
- Заявка **#19675** на dev.hh.ru — "рассматривается"
- Приложение: **Artvision Leads**
- Redirect URI: `https://artvision.pro/oauth/callback`
- Тип: several_employers
- Аккаунт: dune87@yandex.ru (applicant, user_id 113138039)
- После одобрения → обновить .env на VPS (HH_CLIENT_ID, HH_CLIENT_SECRET)

### Login Flow hh.ru (2026)
1. `hh.ru/account/login` → "Я ищу работу" → "Войти"
2. Вкладка "Почта": JS клик по `[class*="magritte-segment"]` с textContent "Почта"
3. `input[name="username"]` → email → "Дальше"
4. Код: IMAP imap.yandex.ru → `<b>(\d{4})</b>`
5. Форма на dev.hh.ru/admin: type=several_employers (one_employer требует employer_id)
6. Submit: кликать кнопку "Добавить" через Playwright, НЕ form.submit() (GET вместо POST)

### Ключевые решения:
- Outreach-домен (типа av-leads.ru) — расходный ящик, основной домен чистый
- Антон обрабатывает ответы сам
- НЕ упоминать hh.ru в письмах — "проанализировали ваш сайт"
- API hh.ru бесплатный, без авторизации для чтения
- Скоринг: HOT (≥60) → TG-алерт, WARM (≥35) → дайджест, COLD (<35) → еженедельно

### VPS Setup
- Деплой: `/opt/hh-leadgen/` на VPS 80.90.181.152
- TG уведомления работают (36 HOT лидов отправлено при первом прогоне)
- Rusprofile: заблокирован CAPTCHA с VPS IP (нужны residential proxies)

### Первый прогон (2026-04-04):
- 1468 вакансий собрано (СПб + Москва + Нижний + Екатеринбург + Новосиб + Казань)
- Дедупликация по employer_id → уникальные компании
