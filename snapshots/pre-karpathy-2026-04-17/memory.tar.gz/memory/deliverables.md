# Готовые результаты и ссылки (обновлено 2026-03-21)

Всё что создано и куда деплоилось. Claude ищет здесь при вопросах "дай ссылку", "где лежит".

## Документы для клиентов

| Документ | Клиент | URL/путь | Дата |
|----------|--------|----------|------|
| NDA Artvision-AdvertMed | AdvertMed | https://artvision.pro/docs/nda/ | 05.03 |
| КП Варикоз v3 | AdvertMed | clients/advertmed-varikozanet/proposals/ | 05.03 |
| КП BluMart (factcheck) | BluMart | clients/blumart/presale/kp/ | 21.03 |
| КП UNO Trans v4 | UNO Trans | clients/unotrans/presale/kp/ | 21.03 |
| КП Roman Mebel | Roman Mebel | clients/roman-mebel/presale/kp/ | 21.03 |
| КП Mirulidi (объединённое) | Mirulidi | clients/mirulidi-clinic/presale/kp/ | 11.03 |
| SEO-аудит Mirulidi v2 | Mirulidi | clients/mirulidi-clinic/seo/ | 19.03 |
| GEO-аудит 6 клиентов | Artvision | docs/ | 19.03 |
| Direct vs SEO forecast UNO Trans | UNO Trans | clients/unotrans/ | 21.03 |
| Аналитический документ Берия | Олег Берия | 20.03 |
| Card Duel revenue toolbox | Card Duel | products/cardwell/revenue-toolbox-2026-03-21.md | 21.03 |
| Card Duel ACTION-MAP | Card Duel | products/cardwell/ | 21.03 |
| CAMEO КП (эталонный дизайн!) | CAMEO | clients/kamey/presale/kp/cameo_kp.html | 03.2026 |

## Поддомены и тестовые URL

| URL | Что | Статус |
|-----|-----|--------|
| https://ant-dev.artvision.pro/ | ANT Partners dev | Работает, SSL |
| https://artvision.pro/docs/nda/ | NDA AdvertMed | Работает |
| https://ai.artvision.pro/ | AIvision лендинг | Работает |
| https://reports.artvision.pro/ | Отчёты клиентов | Работает |
| https://kb.artvision.pro/ | Knowledge base | Работает |
| https://symmetron.artvision.pro/ | Symmetron переводы | Работает |
| https://artvision.pro/artsistant/ | Artssistant лендинг | Работает (18.03) |
| https://artvision.pro/cardwell/ | Card Duel market research | Работает |
| https://artvision.pro/insight/ | ArtSync лендинг | Работает |

## Скрипты и автоматизация

| Скрипт | Назначение | Расписание |
|--------|-----------|-----------|
| scripts/vps_healer.py | Авто-реанимация VPS через Timeweb API | LaunchAgent каждые 5 мин |
| scripts/ip_registry.py | Реестр ИС, SHA-256 хеши | 1 числа каждого месяца |
| scripts/vps_watchdog.sh | Мониторинг SSH | cron каждые 30 мин |
| scripts/position_tracker | Трекинг позиций через Webmaster API | — |

## Боты

| Бот | Платформа | Статус |
|-----|-----------|--------|
| @avportal_bot | Vercel (artvision-tg-bot) | Работает |
| @tvorims_bot | Vercel | Работает |
| vps-bot/bot.js (AI Advisor) | PM2 на VPS | Работает, баги исправлены 18.03 |
| Евразия Max-бот | Не задеплоен | MVP готов, ждём BOT_TOKEN |

## artvision.pro — сайт (обновлено 17-18.03)
- 113 страниц, sitemap 185 URL
- Контент услуг до 1500+ слов (12 стр.)
- 29 кейсов до 800+ слов
- +30 нишевых страниц, +10 городов
- Перелинковка кейсы→похожие + услуги→отрасли
- Линкбилдинг план — в работе
- CRO-аудит готов (5 страниц, 7 измерений)
- 6 SOP документов: Finance, PPC, Dev, PBN, Call, Comms
- Гео-страницы: SEO + PPC для Москвы и СПб
