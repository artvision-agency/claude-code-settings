---
name: Verify client domains before smoke tests
description: ОБЯЗАТЕЛЬНО сверять домен клиента с memory/client_domains_correct.md ПЕРЕД передачей агенту или запуском smoke-теста
type: feedback
originSessionId: 8220ba0f-72ba-4953-8f8b-3d8038862265
---
# Правило: проверка домена перед smoke

**Why:** За сессию 2026-04-17 ошибки с доменами трижды:
1. `avtoworld.ru` вместо `avto.world` (commercial-factors-audit smoke)
2. `tvorim-sovershenstvo.ru` вместо `tvorimsovershenstvo.ru` (link-factors-audit smoke)
3. Агенты получают домен из промпта → повторяют ошибку → результаты невалидны

**How to apply:**
1. Перед ЛЮБЫМ smoke/audit/crawl по домену клиента — прочитать `client_domains_correct.md`
2. При формировании промпта для агента — вставлять домен из memory, не по памяти
3. Если домена нет в memory — проверить `clients/<folder>/config.yaml` или `CLAUDE.md`
4. Домены из shorthand (`творим`, `авто`, `экстру`) → ВСЕГДА разрешать через memory

**Ключевые домены (по состоянию на 2026-04-17):**
- Творим Совершенство → `tvorimsovershenstvo.ru` (слитно, без дефиса)
- Avto.World → `avto.world` (с точкой, не .ru)
