---
name: reference_tg_auto_capture
description: Автоматическая фиксация ответов в TG (Artvision общий чат) → status_requests/responses.jsonl → Asana/TODO/context-log. Telethon daemon + responder + LaunchAgents
type: reference
source: собственная реализация 2026-04-17, см. ~/.claude/scripts/tg-{send-tracked,listener,responder}
fetched: 2026-04-17T11:30:00+03:00
originSessionId: 1e204816-f286-465a-be98-c2269c8ea9dd
---
## Что делает система

Когда я прошу Андрея/Стаса о статусе по задачам — их ответы в общем чате `-4273200821` **автоматически** ловятся, классифицируются и мержатся в реестры. Если ответ непонятный — Claude формирует follow-up (с лимитом 2 переспрашивания, потом эскалация).

## Компоненты

| Файл | Роль |
|------|------|
| `~/.claude/scripts/tg-send-tracked.sh` | Отправка сообщения + регистрация ожидаемых вопросов в трекере |
| `~/.claude/scripts/tg-listener.py` | Telethon daemon — слушает чат, матчит ответы к активным запросам |
| `~/.claude/scripts/tg-responder.py` | Классификатор + side effects (context-log, архив, follow-up) |
| `~/Library/LaunchAgents/pro.artvision.tg-listener.plist` | Daemon 24/7 |
| `~/Library/LaunchAgents/pro.artvision.tg-responder.plist` | Запускается каждые 120 сек с `--auto-clarify` |

## Данные

- `~/artvision-data/sync/tg-tracking/status_requests.jsonl` — список запросов (вопросы → статус)
- `~/artvision-data/sync/tg-tracking/tg_responses.jsonl` — сырые матченные ответы
- `~/artvision-data/sync/tg-tracking/archive/` — завершённые запросы (md)
- `~/artvision-data/sync/tg-tracking/listener.log` + `responder.log` — диагностика

## Использование (как я должен делать статус-запрос)

```bash
# Вместо tg-send.sh — tg-send-tracked.sh с --questions
~/.claude/scripts/tg-send-tracked.sh team andrey \
  "@PandaCaffe статус по задачам:
1. Avto.world прогон — прошёл?
2. Geely A2Auto — статус?
3. Extru март/апрель — отчёт готов?" \
  --questions "Avto.world прогон||Geely A2Auto||Extru отчёт"
```

Listener подхватит ответы (по `reply_to` ИЛИ по sender+window 60 мин + префиксу `^(\d+)[.,)\-:]`). Responder классифицирует (`confirmed/partial/blocker/ambiguous`) и при `ambiguous` автоматически отправит follow-up (`--auto-clarify`).

## Статусы запроса

| Status | Что значит |
|--------|-----------|
| `awaiting` | Ждём ответа |
| `completed` | Все вопросы закрыты → архив |
| `escalate` | Превышен лимит переспрашивания (MAX_CLARIFY=2) → эскалация Антону |

## Классификация ответа

| Ключевые слова | Status |
|----------------|--------|
| "да", "готово", "done", "прошёл", "завершено", "опубликовано", URL | `confirmed` |
| "нет", "не сделано/закрыт", "блокер", "упал", "ошибка" | `blocker` |
| "частично", "только", "март есть / апрель нет", "+N", "N из M" | `partial` |
| Короткое/неопределённое | `ambiguous` |

## Управление

```bash
# Статус daemon
launchctl list | grep artvision

# Перезапуск
launchctl unload ~/Library/LaunchAgents/pro.artvision.tg-listener.plist
launchctl load ~/Library/LaunchAgents/pro.artvision.tg-listener.plist

# Разовый backfill (если daemon падал)
python3 ~/.claude/scripts/tg-listener.py --backfill 2h

# Ручной прогон responder
python3 ~/.claude/scripts/tg-responder.py --auto-clarify
```

## Известные ограничения (MVP → TODO)

- **Asana sync ещё не подключён.** Сейчас пишется только в общий `context-log.md`. TODO: по `asana_gid` в questions — двигать статусы через Asana MCP.
- **Роутинг context-log по клиенту.** Сейчас всё в `~/artvision-data/context-log.md`. TODO: парсить из текста вопроса client slug → писать в `clients/<X>/context-log.md`.
- **Mac-only LaunchAgent.** Работает пока Mac включён. Миграция на VPS возможна: перенести session-файл + pip3 install telethon на VPS + systemd unit.
- **Классификатор = regex.** Для сложных ответов можно добавить LLM-классификацию (llm-consilium MCP: `ask_auto`).
- **Только 1 чат.** `WATCHED_CHATS = [-4273200821]`. Клиентские DM позже.

## Pre-clarify factcheck (добавлено 2026-04-17)

Перед отправкой follow-up — responder сам проверяет, не выполнена ли уже задача:

| Источник | Что ищет | Требования |
|----------|----------|------------|
| `tg_responses.jsonl` (7 дней) | confirmed/partial ответ с keywords | classify=confirmed/partial |
| `clients/*/context-log.md` (48ч) | строка с keywords + маркер выполнения | ≥2 keyword match + маркер в окне ±2 строки |
| `git log artvision-data` (48ч) | commit с feat/fix/publish/deploy | ≥2 keyword match + action verb |
| `archive/*.md` | закрытые раньше похожие вопросы | ≥2 keyword match + confirmed/✅ |

Если evidence найден → вопрос `confirmed`, в answer добавляется `[auto-factcheck: <источник>] <evidence>`. Follow-up не отправляется.

**Принцип:** better false-negative (спросить лишний раз) чем false-positive (пометить закрытым ложно). Поэтому:
- Минимум 2 keyword match (не 1)
- Обязателен маркер выполнения — простое упоминание темы не засчитывается
- Окно свежести: 48ч для логов, 7 дней для responses history

## История

- **2026-04-17 11:30:** MVP реализован. Backfill на утренних 6 ответах Андрея — 6/6 матчей, классификация 2✓/2○/2∘.
- **2026-04-17 11:36:** Добавлен pre-clarify factcheck (4 источника), фикс classifier (сделаны/сделала/готовы/прошли). Утренний req_20260417_0802_andrey автозакрыт после переклассификации q6 (сделаны → confirmed).
