---
name: Screaming Frog CLI — локальная установка
description: Как на новой машине поднять `sf` wrapper + SEO-хук, чтобы Claude автоматом использовал SF вместо WebFetch
type: reference
---

# Screaming Frog CLI — `sf` команда

**Где:** `~/.local/bin/sf` (должен быть в PATH)
**Что делает:** обёртка над `/Applications/Screaming Frog SEO Spider.app/.../ScreamingFrogSEOSpiderLauncher` (прямой symlink ломается — launcher ищет `universalJavaApplicationStub` в той же папке)

## Установка на новой машине

1. Установить Screaming Frog SEO Spider.app (https://www.screamingfrog.co.uk/seo-spider/)
2. `bash ~/claude-code-settings/scripts/install-sf-wrapper.sh` — создаст `~/.local/bin/sf`
3. Проверка: `sf --help`

## Автоматика

**Хук** `seo-use-sf-reminder.sh` (UserPromptSubmit) — на ключевых словах (seo аудит, краул, битые ссылки, canonical, orphan pages, дубли meta) вставляет в контекст напоминание вызвать `sf` вместо WebFetch/агентов.

Зеркала: `~/.claude/hooks/`, `~/artvision-data/.claude/hooks/`, `~/claude-code-settings/hooks/`.
Зарегистрирован в `~/.claude/settings.json` → UserPromptSubmit.

## Пример команды

```
sf --crawl https://example.com --headless --save-crawl \
   --export-tabs "Internal:All,Response Codes:Client Error (4xx),Page Titles:Duplicate" \
   --output-folder /tmp/sf-out --overwrite
```

## Обёртка

`~/artvision-data/scripts/seo-toolkit.py` — Python-пайплайн, вызывает SF + Lighthouse + GSC-экспорты.

## Лицензия

Без лицензии лимит 500 URL. Ключ проверяется в SF.app → Licence. £239/год.
