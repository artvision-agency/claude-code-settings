---
name: feedback_factcheck_autofix
description: After factcheck finds broken URLs — fix them automatically without asking, then re-run factcheck
type: feedback
---

ОБЯЗАТЕЛЬНО после factcheck с CRITICAL — автоматически исправить ВСЕ битые ссылки БЕЗ вопросов.

**Why:** Антон ожидает автономности — "ты это сам должен проверять и исправлять", "зачем спрашивать". Factcheck → fix → re-factcheck = один цикл, не 3 шага с подтверждениями.

**How to apply:**
1. Запустить factcheck
2. Если CRITICAL > 0 — сразу искать рабочие замены (curl -sI проверка)
3. Заменить все битые URL
4. Перезапустить factcheck
5. Если CRITICAL = 0 → деплоить
6. Показать итог: было X CRITICAL → 0
