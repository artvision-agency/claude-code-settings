---
name: Транскрибация созвонов — Groq first, phase0_pipeline внутри
description: При ЛЮБОЙ задаче транскрибации аудио/видео — НЕ запускать локальный whisper. Использовать Groq API или products/sales-psychology/phase0_pipeline.py
type: feedback
originSessionId: c5419b30-c9d4-454f-aff4-75c82b7c4cd5
---
**Правило:** при просьбе транскрибировать mp4/m4a/mp3 — запрещено запускать локальный whisper (medium/large-v3/turbo на CPU). Использовать Groq API или существующий pipeline `products/sales-psychology/phase0_pipeline.py`.

**Why:** 2026-04-13 Антон прислал 20-мин созвон с Киселевым. Запустил локальный whisper-medium, потом turbo — оба ушли в UN-состояние, 12+ минут без вывода. Антон напомнил, что у нас ЕСТЬ готовый продукт для этого (Artvision Insight = `products/sales-psychology/`) с phase0_pipeline.py (Audio → Whisper → Claude → Summary + DISC + HTML). Я велосипедил. Groq whisper-large-v3-turbo дал 9901 символ за секунды (FREE, токен в tokens.json → `groq.api_key`).

**How to apply:**
1. Аудио/видео созвон → первая мысль: Groq API, не локальный whisper
2. Для созвонов с клиентами/командой → `phase0_pipeline.py` (уже даёт summary + DISC + HTML)
3. Быстрый вариант (только текст):
   ```bash
   GROQ_KEY=$(python3 -c "import json; print(json.load(open('/Users/antonk/artvision-data/tokens.json'))['groq']['api_key'])")
   curl -s -X POST "https://api.groq.com/openai/v1/audio/transcriptions" \
     -H "Authorization: Bearer $GROQ_KEY" \
     -F "file=@AUDIO.m4a" -F "model=whisper-large-v3-turbo" \
     -F "language=ru" -F "response_format=verbose_json" -F "temperature=0" \
     -o ~/transcripts/NAME.json
   ```
4. Если файл видео — сначала `ffmpeg -i video.mp4 -vn -acodec copy audio.m4a` (или `-c:a libmp3lame -q:a 4` для mp3)
5. Результат → `~/transcripts/<имя>-YYYY-MM-DD.{json,txt}`
6. Саммари созвона → `clients/<client>/meetings/YYYY-MM-DD-<topic>.md`
