---
name: video-content-storage
description: Временное хранение видеоконтента — Google Drive и Яндекс.Диск (два места)
type: reference
---

Временный видеоконтент хранится в двух местах:

1. **Google Drive:** https://drive.google.com/drive/folders/17wt4GJlfvGJJLPbiUyCcRD6g6CJL7dDd (папка "Размещение материалов" от бота @avportal_bot)
2. **Яндекс.Диск:** https://disk.yandex.ru/client/disk

**How to apply:** При работе с видео/фото/документами для клиентов — загружать/искать в этих двух хранилищах. Google Drive — основной (фото, документы, контент для публикации), Яндекс.Диск — резервный.
