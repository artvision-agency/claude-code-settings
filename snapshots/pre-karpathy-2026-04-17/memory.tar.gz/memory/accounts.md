# Аккаунты для регистрации сервисов

## Правила выбора email
- **Русские сервисы:** dune87@yandex.ru
- **Международные сервисы:** antoniokmr@gmail.com
- **Пароль везде:** Testtest123]

## Контакты Антона
- **Телефон:** +7 (911) 086-18-88

## Основные рабочие аккаунты (НЕ для регистраций)
- justtrance@gmail.com — основной (Claude Max, GitHub, Google)
- adw.artvision.pro@gmail.com — рабочий (Claude Max)

## Команда
- **Антон Камеристый** — owner, @antonkamer, СПб Петроградка. Фамилия: **Камеристый** (НЕ Каменов!)
- **Андрей Киселёв** — employee, @PandaCaffe
- **Стас** — gamedev, GitHub: Stanislav2014, Claude Code user

## Asana аккаунты команды
- **Андрей** → `boss@artvision.pro` (GID: `11616861546187`)
- **Антон** → `justtrance@gmail.com` (GID: `860693669618957`) или `antoniokmr@gmail.com` (GID: `1212367692929434`)
- **Стас** → `madsmile666666@gmail.com` (GID: `1213276861763289`)

## Claude Max подписки (2026-02-16)
- **justtrance@gmail.com** — Антон, Max подписка, Claude Code + claude.ai
- **adw.artvision.pro@gmail.com** — Андрей, Max подписка, Claude Code + claude.ai
- **Max = 20x относительно Pro** (НЕ 5x — 5x это промежуточный план)
- Лимит сбрасывается в **3:00 MSK** (еженедельно)
- Если упёрся в лимит → переключиться на другой аккаунт

## Telegram — контакты и чаты
- **Бот Artvision:** @avportal_bot (tokens.json → telegram.portal_bot.**token** — это dict, не строка!)
- **Бот Творим:** @tvorims_bot (отдельный бот, НЕ путать с @avportal_bot!)
- **Группа команды:** chat_id: `-4273200821` (из tokens.json → telegram.group_chat_id)
- **Антон:** TG 161261562, **Андрей:** TG 1857522687 (@PandaCaffe), **Стас:** TG 356640470

## Зарегистрированные сервисы

| Сервис | Email | Дата | API Key | Статус |
|--------|-------|------|---------|--------|
| remove.bg (Kaleido) | antoniokmr@gmail.com | 2026-02-23 | poeXpUen73acY6eagFzsWSiX | Active, free plan |
| remove.bg (old) | justtrance@gmail.com | ? | ? | Пароль утерян, сброс отправлен |
| **Semrush** | kulikov.v.art@gmail.com | ? | В tokens.json | Active, Playwright login |
