---
name: artvision.pro naming
description: ВСЕГДА писать artvision.pro (с маленькой буквы + .pro) — НИКОГДА не Artvision, не ARTVISION, не artvision без .pro
type: feedback
---

ВСЕГДА писать **artvision.pro** — с маленькой буквы и обязательно с .pro.

**Why:** Антон явно потребовал — это бренд-стандарт. Навсегда, везде, без исключений.

**How to apply:** В любом тексте — КП, письма, чаты, документы, код, memory — только `artvision.pro`. Не "Artvision", не "ARTVISION", не "artvision" без `.pro`.
