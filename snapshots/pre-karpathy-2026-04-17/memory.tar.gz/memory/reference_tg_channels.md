---
name: reference_tg_channels
description: Рабочие TG-каналы по получателям — кому куда писать, где DM не работает, fallback через team chat
type: reference
source: /Users/antonk/artvision-data/sync/HANDOFF_2026-04-10.md:15 + sync/SESSION_STATE.json:97
fetched: 2026-04-17T11:05:00Z
originSessionId: 1e204816-f286-465a-be98-c2269c8ea9dd
---
## Маршрутизация TG-отправок (через @avportal_bot)

| Получатель | Chat ID | DM работает? | Рабочий канал | Команда |
|---|---|:---:|---|---|
| **Anton** | `326925698` | ✅ | DM | `tg-send.sh anton "..."` |
| **Andrey (@PandaCaffe)** | `1857522687` | ❌ "chat not found" | Team group chat с упоминанием `@PandaCaffe` | `tg-send.sh team "@PandaCaffe ..."` |
| **Stas** | `356640470` | ⚠️ не проверено — тестировать | (по умолчанию team chat) | `tg-send.sh team "@... ..."` |
| **Admin (Anton)** | `161261562` | ✅ | DM (админ-нотификации) | `tg-send.sh 161261562 "..."` |
| **Команда (group)** | `-4273200821` | ✅ | Групповой чат Artvision | `tg-send.sh team "..."` |

## Правило

**ВСЕГДА** при отправке сообщения человеку:
1. Проверить эту таблицу.
2. Если получатель ≠ в таблице → попробовать DM, при "chat not found" → fallback через team chat с упоминанием.
3. После успешной отправки: запись автоматически идёт в `~/artvision-data/sync/HANDOFF_<today>.md` (через `tg-send.sh`).
4. Если DM новый получатель НЕ работает → ДОПИСАТЬ сюда строку.

## История инцидентов

- **2026-04-10:** Первый раз задокументировано — msg_id 6022 к Андрею через team chat (HANDOFF_2026-04-10.md:15).
- **2026-04-17:** Повтор — пытался DM 1857522687 → "chat not found" → fallback team chat успешен. Причина повтора: SessionStart не читает HANDOFF, memory не содержала правила маршрутизации. Добавлено это правило + логгер в tg-send.sh + хук.

## Связанные файлы

- `~/.claude/scripts/tg-send.sh` — обёртка с автологом в HANDOFF
- `~/.claude/scripts/notify-telegram.sh` — низкоуровневый curl
- `~/artvision-data/sync/HANDOFF_<date>.md` — журнал отправок (append-only)
- `~/.claude/hooks/start-restore-session.sh` — при старте читает HANDOFF за последние 2 дня
