---
name: Allen 10 Streams × AI Analysis
description: Анализ 10 потоков дохода Robert Allen через призму AI для Artvision. ТОП-3 реализуемых + action plan
type: project
---

# 10 потоков Allen × AI: результаты консилиума (2026-03-27)

**Источник:** Robert Allen "Multiple Streams of Income" PDF
**Метод:** 3 параллельных агента (researcher + factchecker + strategist)

## Вердикт: 3 из 10 релевантны для Artvision

| # | Поток | Вердикт | AI-усиление | Потенциал RUB/мес |
|---|-------|---------|:-----------:|:-----------------:|
| 8 | **Infopreneuring** | CONFIRMED | 9/10 | 100-800K |
| 10 | **Internet Business (SaaS)** | CONFIRMED | 10/10 | 200K-2M |
| 9 | **Licensing (IP)** | CONFIRMED частично | 8/10 | 100K-1.5M |

## Отброшенные (7 потоков)

| Поток | Причина отбраковки |
|-------|--------------------|
| Tax Liens | US-only, AI-инструментов нет |
| Options/Leverage | 90% ритейла теряет деньги (ESMA) |
| Flipping | Нужен $20K+ и локальный рынок |
| MLM | DEBUNKED — 99% теряют деньги (FTC) |
| Real Estate (hold) | Нет капитала $50K+, высокие ставки РФ |
| Accelerated Stocks | Хайп > реальность для ритейла |
| Stock Market (passive) | Только для реинвестирования прибыли, не бизнес |

## ТОП-3 Action Plan

### 1. Infopreneuring (запуск 2-4 недели)
- SEO Automation Toolkit (88 скриптов → пакет)
- Шаблоны КП (эталон CAMEO)
- Курс "Claude Code для маркетологов"
- Цена: 4,900 / 14,900 / 49,900 RUB

### 2. SaaS (MVP 1-3 мес)
- AIvision подписка (GEO-аудит)
- SEO Pipeline как SaaS (Artvision Flow)
- Артссистант white-label
- Аналоги: PhotoAI $132K MRR (solo), медиана micro-SaaS $4.2K MRR

### 3. Licensing (outreach 2-4 недели)
- SEO Pipeline → Docker + ключ другим агентствам
- Бот-платформа как шаблон
- Artvision Pulse/Scout брендированные отчёты
- Цена: 19,900 / 49,900 / 99,900 RUB/мес

## Расчёт к 2M/мес

```
Текущие клиенты:     511K
+ Инфопродукты:      +100-300K
+ SaaS MVP:          +200-500K
+ Лицензии:          +100-200K
+ Upsell текущих:    +100-200K
= ИТОГО к июню:      1.0M - 1.7M → масштабирование Q3 → 2M+
```

**Why:** Прямая привязка к цели 2M→5M. Allen даёт философию множественных потоков, но конкретные инструменты заменены на digital-native 2026.
**How to apply:** При планировании новых продуктов и revenue streams — сверяться с этим анализом. Приоритет: infopreneuring (самый быстрый ROI), затем SaaS, затем licensing.
