# MODX CMS — уроки и паттерны

### pdoResources LEFT JOIN обходит template-TV assignment (2026-02-24)
`pdoResources` с `&includeTVs=preview` делает LEFT JOIN на `site_tmplvar_contentvalues` напрямую — **не проверяет** назначена ли TV шаблону. INSERT значения в `site_tmplvar_contentvalues` достаточно, даже если TV не назначена шаблону через `site_tmplvar_templates`.

### Standalone PHP скрипты для MODX = preview/execute (2026-02-24)
1. `?mode=preview` — показывает что будет изменено, НЕ меняет
2. `?mode=execute` — применяет изменения + чистит кеш
3. Подключение через `core/config/config.inc.php` (быстрее чем MODX API bootstrap)
4. **УДАЛЯТЬ скрипт сразу после использования**

### SVG-иконки — стиль для ant.partners (2026-02-24)
- `viewBox="0 0 100 100"`, `fill="none"`, `stroke="#4A7BA7"`
- `stroke-width="2.5"`, `stroke-linecap="round"`, `stroke-linejoin="round"`
- Путь: `files/images/uploads/{resource_id}/preview/{name}.svg`

### SVG `<text>` элемент ломает `<img>` рендер (2026-02-24)
**НИКОГДА** не использовать `<text>` в SVG которые подключаются как `<img src="...">`.

### SVG дизайн для маленьких размеров 70x70px (2026-02-24)
2-3 крупных элемента лучше чем 10 мелких. Прямоугольники > линии. 11 итераций для одной иконки.

### FTP upload: webroot = public_html/, НЕ FTP root (2026-02-24)
```bash
curl -T file.svg --user "user:pass" --ftp-create-dirs "ftp://host/public_html/files/images/uploads/8/preview/file.svg"
```

### MODX + MySQL utf8 = emoji обрезают строку (2026-02-18)
Фикс: убрать emoji ДО деплоя или ALTER TABLE → utf8mb4.

### MODX VersionX = спасение при откате (2026-02-24)
Fields = PHP `serialize()`, НЕ JSON. TV в VersionX = 0-indexed массив. ВСЕГДА `?mode=preview` → `?mode=execute`.
