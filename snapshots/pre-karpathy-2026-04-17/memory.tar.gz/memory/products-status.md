# Статусы продуктов Artvision (обновлено 2026-03-21)

## ArtSync / Artvision Insight — Sales Psychology
- **Продукт:** Real-time sales intelligence — подсказки во время переговоров
- **Публичное имя:** Artvision Insight
- **Pipeline:** Research [x] → Phase 0 [~] → Phase 1 → Phase 2 → Phase 3
- **3 слоя:** Транскрипция (Whisper/SpeechKit) → Накопительный психопортрет (DISC) → Real-time подсказки
- **OSINT модуль:** фото→соцсети (Search4faces), анализ контента→психопрофиль
- **Дизайн-док:** `products/sales-psychology/design-doc.md`
- **Market research:** `products/sales-psychology/market-research-2026-03.md`
- **Прототип:** `clients/advertmed-varikozanet/meetings/sales-psychology-analysis.md` (ручной анализ 4 встреч)
- **USP:** русский язык + OSINT + накопительный профиль + real-time (нет аналогов в РФ)
- **Конкуренты:** Gong ($100-300/user/mo), Read.ai ($20-40/mo), Crystal Knows ($49-199/mo)
- **Монетизация:** Lite 3K/мес, Pro 15K/мес, Enterprise 50K/мес, Agency 100K/мес
- **Цель:** 500K/мес
- **Статус:** design-doc + market research готовы, Phase 0 не начат
- **Следующее:** начать Phase 0 на записях Варикознет

## AIvision (ai.artvision.pro)
- **Публичное имя:** Artvision Radar
- **Pipeline:** Лендинг [x] → GEO-шаблон [ ] → Продажи [ ]
- **Стратегия:** гибрид — услуги сейчас → автоматизация → SaaS к сентябрю
- **Домен:** ai.marketing (TLD .marketing, решено 2026-03-24), ai.artvision.pro (старый), aivision.ru (free-date: 2026-09-15), ai-vision.ru (free-date: 2026-08-23)
- **Услуги:** GEO-аудит, GEO-оптимизация, AI Commerce Readiness, Радар конкурентов, AI-контент
- **GEO-аудит 6 клиентов** проведён (март 2026) — видимость в AI-поисковиках
- **20 компаний** для cold outreach с GEO-аудитами подготовлены
- **Цель:** 100K/мес
- **Следующее:** создать шаблон GEO-аудита как услуги

## Card Duel (playden.games)
- **Pipeline:** Research [x] → Dev [x] → Yandex [x] → Monetization [~] → Multi-platform [ ]
- **Репо:** `Stanislav2014/card-duel` (private, master) | Форк: `artvision-agency/card-duel`
- **Стек:** Vue 3 + Pinia + TypeScript + Colyseus PvP (Docker)
- **VPS:** 147.45.232.226 :3001 (Colyseus Docker + Nginx proxy)
- **Домен:** playden.games
- **IP:** 100% Stanislav Muravev | Artvision = стратегия + маркетинг + монетизация
- **Антон = монетизация** (регистрации, SDK, ads, аналитика, submit на платформы)
- **Yandex Games:** принят, играбелен
- **9 билдов:** Yandex, TG, CrazyGames, Poki, VK, FB, itch.io, OK, GameDistribution
- **Revenue toolbox:** `products/cardwell/revenue-toolbox-2026-03-21.md`
- **ACTION-MAP:** `products/cardwell/` — полный pipeline от кода до денег
- **В процессе:** Adsgram Block ID (не настроен), GameAnalytics (не подключен)
- **Цель:** $2K/мес
- **Следующее:** зарегистрировать Adsgram + GameAnalytics, submit CrazyGames/Poki/itch.io

## Artssistant (цифровой ассистент)
- **Публичное имя:** Artssistant (Artvision + Assistant). НЕ "бот"!
- **Pipeline:** Лендинг [x] → КП-шаблон [x] → Лиды [x] → Outreach [ ] → Upsell [ ]
- **Лендинг:** artvision.pro/artsistant/ (18.03)
- **КП-шаблон:** для автосервисов готов
- **20 лидов:** автосервисы СПб+МСК собраны
- **Целевые ниши:** медклиники, автосервисы, образование
- **Чек:** 150-400K/мес (настройка + абонентка)
- **Кейс:** @tvorims_bot (Творим Совершенство)
- **Следующее:** холодный outreach по списку + upsell текущим клиентам

## PolyTrends Bot (НОВЫЙ, март 2026)
- **Pipeline:** Design [x] → Plan [x] → Implementation [ ] → Deploy [ ]
- **Репо:** `github.com/artvision-agency/polytrends-bot` (private)
- **Путь:** `~/polytrends-bot/`
- **Суть:** TG-бот мониторинга трендов (Polymarket и др.)
- **Дизайн-документ:** готов (18.03)
- **План имплементации:** 12 задач, TDD (18.03)
- **Следующее:** имплементация по плану

## Директ-Радар (Artvision Scout)
- **Pipeline:** MVP [x] → Sales Kit [x] → Тест на клиентах [ ]
- **Суть:** мониторинг конкурентов в Яндекс.Директе
- **Скрипт + документация + SALES-KIT** готовы
- **Следующее:** выбрать 3 клиентов для тестирования

## EMD Site Network (ретаргетинг микросайты)
- **Pipeline:** Research [x] → Scaffold [x] → Деплой [ ]
- **50 запросов**, scaffold генератор, 5 калькуляторов (ROAS/CPM/CPC/A-B/AEO)
- **Следующее:** купить домены и задеплоить калькуляторы

## Structural Engineering (stressedskin.io)
- **Pipeline:** Excel [x] → Домен [ ] → Stripe → Product Hunt
- **Цель:** GBP 2K/мес
- **Статус:** давно без движения
- **Следующее:** приоритизировать или заморозить

## Бабуров (идея, 2026-03-09)
- **Идея:** TG-бот "Мой план лечения" для стоматологии (Mini App)
- **Файл:** `presales/baburov-treatment-plans/idea.md`
- **Дашборд:** Wordstat + конкуренты готов (13.03)
- **Статус:** ждём решение
- **Потенциал:** 60-100K разово + 15-25K/мес

## MsBox (почтовый ящик для мессенджеров)
- **Путь VPS:** `/root/msbox/`, standalone python (pid 917)
- **Токен:** `8341077643` (ОТДЕЛЬНЫЙ от avportal `8399522625`)
- **Стек:** aiogram 3.x, SQLite
- **Статус:** MVP запущен, Антон вспомнил как забытый продукт (22.03)
- **Следующее:** ревизия, определить MVP roadmap

## AI Advisor (vps-bot)
- **Суть:** Telethon userbot для мониторинга клиентских чатов
- **Критические баги** исправлены (stale date, empty catch, userModes) — 18.03
- **Retry Groq/Asana 429 + broadcast throttle** — 18.03
- **Статус:** фиксы готовы, нужен деплой на VPS + тесты
