---
name: feedback_bot_monitoring
description: ОБЯЗАТЕЛЬНЫЙ мониторинг для КАЖДОГО production бота и сервиса — healthcheck + auto-restart + алерты
type: feedback
---

## Правило: каждый production бот/сервис = healthcheck с первого дня

При создании или деплое ЛЮБОГО бота (Telegram, API, сервис на VPS) — ОБЯЗАТЕЛЬНО добавлять мониторинг.

**Why:** Инцидент 2026-03-12 — бот @tvorims_bot был сломан 2 часа (баг в коде), узнали только от пользователя. Пациентка не смогла завершить flow. Без мониторинга — каждый час простоя = потерянные клиенты/отзывы/деньги.

**How to apply:**

### Чеклист для КАЖДОГО нового бота/сервиса:

1. **systemd service** с `Restart=always` и `RestartSec=10`
2. **healthcheck.py** — проверка каждые 5 мин через cron:
   - Процесс жив? (`systemctl is-active`)
   - Ошибки в логах? (паттерны: Traceback, Error, Conflict)
   - API отвечает? (getMe для ботов, /health для API)
3. **Авто-restart** — 3 подряд ошибки (15 мин) → `systemctl restart`
4. **Алерты** — лично админам (не в группу — теряется в шуме):
   - Первая ошибка → мгновенный алерт
   - Повтор каждые 30 мин пока не починено
   - Восстановление → "бот восстановлен" с кол-вом пропущенных проверок
5. **State-файл** — дедупликация алертов, подсчёт consecutive failures

### Шаблон healthcheck уже есть:
- **Файл:** `artvision-tg-bot/tvorims-bot/healthcheck.py` — копировать и адаптировать
- **Cron:** `*/5 * * * * cd /opt/SERVICE && export $(grep -v "^#" .env | xargs) && python3 healthcheck.py >> /var/log/SERVICE-healthcheck.log 2>&1`

### Проверка после КАЖДОГО деплоя (обязательно):
```bash
ssh VPS "journalctl -u SERVICE -n 20 --since '1 min ago'"
```

### Для будущих продуктов (AIvision, Lead Auction, боты клиентов):
- Мониторинг закладывать В АРХИТЕКТУРУ, не добавлять потом
- Скилл `telegram-bot-deployment` должен включать шаг "настройка healthcheck"
- Каждый продукт на VPS = healthcheck + cron + алерты с первого деплоя
