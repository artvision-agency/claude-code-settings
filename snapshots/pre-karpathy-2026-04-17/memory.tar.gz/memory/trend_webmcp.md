---
name: trend_webmcp
description: WebMCP (W3C) — стандарт для AI-агентов взаимодействия с сайтами. Google+Microsoft, Chrome 145+. Связь с AIvision/GEO.
type: reference
---

**WebMCP** — W3C стандарт (Google + Microsoft), позволяет сайтам описывать действия для AI-агентов.
Вместо скриншот+клик → прямой вызов функций (buyTicket, bookAppointment).

**Источник:** https://developer.chrome.com/blog/webmcp-epp
**Статус:** Chrome 145+ early preview, за флагом (март 2026)

**Why:** Веб перестраивается под AI-агентов. Сайты с WebMCP будут получать приоритет от AI-систем — как сайты с Schema.org получают rich snippets.

**How to apply:**
1. **GEO-аудит (/geo-audit):** добавить проверку WebMCP-readiness как будущий чекпоинт
2. **AIvision продукт:** WebMCP-оптимизация как услуга (когда стандарт стабилизируется)
3. **Клиентские сайты:** готовить описания действий (запись, заказ, звонок) в машиночитаемом формате
4. **Наши агенты:** использовать WebMCP endpoints вместо Playwright для скрейпинга
5. **Экономика:** сайт видит agent vs human — можно строить отдельную воронку для AI-трафика
