---
name: google-service-account-auth
description: Google Drive/Docs доступ через Service Account — без 2FA/пароля. Путь к ключу, email, рабочий pipeline.
type: reference
originSessionId: 270c0fb8-4dee-4b64-9639-ba10bd1cac69
---
## Google Service Account для автоматизации

**Ключ:** `/Users/antonk/Desktop/_archive_2026/silent-album-187415-de016a15a29f.json`
**Email:** `seo-bot@silent-album-187415.iam.gserviceaccount.com`
**Project:** `silent-album-187415`
**Scopes:** `https://www.googleapis.com/auth/drive`

### Почему это важно
- Оба Google-аккаунта (justtrance, adw.artvision.pro) требуют 2FA/passkey — Playwright не пройдёт
- Service Account аутентифицируется через private key — без пароля, без 2FA, без браузера
- Работает через google-api-python-client (pip3 install google-auth google-api-python-client)

### Рабочий код (проверен 2026-03-18)
```python
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SA_FILE = '/Users/antonk/Desktop/_archive_2026/silent-album-187415-de016a15a29f.json'
creds = service_account.Credentials.from_service_account_file(
    SA_FILE, scopes=['https://www.googleapis.com/auth/drive']
)
drive = build('drive', 'v3', credentials=creds)

# Upload/update file
media = MediaFileUpload(local_path,
    mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    resumable=True)
drive.files().update(fileId=FILE_ID, media_body=media).execute()
```

### Ограничения
- Файл в Google Drive должен быть расшарен на seo-bot@silent-album-187415.iam.gserviceaccount.com (Editor)
- Export в text/plain не работает для .docx (только native Google Docs) — скачивай через get_media() и проверяй python-docx
- Для новых документов: сначала расшарить на SA, потом автоматизировать

### Стратегия эскалации доступа (обновлённая)
1. **Service Account** (silent-album-187415) — ПЕРВЫЙ вариант, без 2FA
2. Chrome profile + Playwright — если SA не имеет доступа к файлу
3. OAuth flow — требует браузер + 2FA
4. Спросить пользователя — ПОСЛЕДНИЙ вариант

### Рабочая папка SA (2026-04-15)
**Artvision — Claude Access** (SA = owner, justtrance@ = Editor)
- ID: `1kHpBApAT7L6o8oIW8Kh4GXQAp5cyFnIv`
- URL: https://drive.google.com/drive/folders/1kHpBApAT7L6o8oIW8Kh4GXQAp5cyFnIv
- Подпапки: Клиенты, КП, Отчёты, Встречи, Общие материалы
- Всё внутри доступно SA автоматом (не нужно расшаривать по файлу)

### Хелпер
`artvision-data/scripts/gdrive.py` — CLI: ls/mkdir/doc/sheet/upload/share/read
Пример: `python3 scripts/gdrive.py doc "КП Che-Group"`
