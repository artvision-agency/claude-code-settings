---
name: VPN usage
description: Антон использует Ultima VPN на телефоне
type: user
---

Используют Ultima VPN на телефоне.
