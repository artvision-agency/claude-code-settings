---
name: Ирина — админ Творим Совершенство
description: Роль Ирины в проекте @tvorim_opros_bot — админ клиники, получает все уведомления опросника
type: project
originSessionId: 8308712b-5546-47a9-b4b0-8d848e20e9b7
---
# Ирина — админ клиники Творим Совершенство

## Факт
Ирина — **админ клиники** Творим Совершенство. Не пациент, не менеджер — именно админ.

**Why:** ранее в `lessons-tvorims-bot.md` было записано "Ирина — пациентка" (неверно). Антон исправил 2026-04-17: она админ клиники.

## How to apply

### Для @tvorim_opros_bot
- Ирина получает **ВСЕ** уведомления об опросах пациентов (наравне с Антоном)
- Её chat_id должен быть в admin list: `tokens.json.telegram.tvorim_opros_bot.admin_chat_ids` (массив) или отдельный `irina_chat_id`
- НЕ фильтровать уведомления — она должна видеть всё как Антон

### Для @tvorims_bot (основной бот клиники)
- Если возникнут админские уведомления — Ирина в списке получателей
- Тест-сообщения при деплое — можно слать ей как proof of delivery

### chat_id
**`5138759355`** — найден в `sessions.json` @tvorims_bot (тестовый прогон 11-12.03.2026).
Записан в `tokens.json.telegram.tvorim_opros_bot.irina_chat_id`, задеплоен на VPS 2026-04-17.

**ВАЖНО:** chat_id универсален для Telegram, но @tvorim_opros_bot сможет писать Ирине только ПОСЛЕ того как она хотя бы раз нажмёт Start в этом боте (ограничение Bot API: `Forbidden: bot can't initiate conversation`).

## Связанные файлы
- `~/artvision-tg-bot/tvorim-opros-bot/config.py` — admin list
- `~/artvision-tg-bot/tvorim-opros-bot/bot.py` — `/getid` handler
- `lessons-tvorims-bot.md` — **исправить** запись про "пациентку"
