---
name: Read project folder before any task
description: ОБЯЗАТЕЛЬНО читать содержимое папки проекта (ls, find) перед началом работы — чтобы знать что уже есть
type: feedback
---

При вызове задачи по проекту клиента — СРАЗУ читать что есть в папке проекта:
- `ls -R clients/[name]/` — структура
- Медиа-файлы (img/, videos/, chess-videos/)
- Предыдущие версии (index-v1..v7.html)
- Что уже залито на VPS (`ssh ... ls /var/www/.../`)

**Why:** Залил Esenina v8 без фото, потому что не проверил что фото лежат в `chess-videos/` и в `esenina-test/img/` на VPS. Потерял время.

**How to apply:** Добавить в Pre-Task Protocol: `ls` + `find` папки клиента ПЕРЕД любой работой. Особенно перед деплоем — проверить что все ассеты на месте.
