---
name: tvorim-competitor-landings
description: 13 конкурентных лендингов стоматологий СПб (All-on-4, имплантация, виниры) — отправлены случайно 2026-03-12, сохранены для будущего анализа
type: project
---

Список конкурентных лендингов стоматологий СПб, полученный 2026-03-12.

**Why:** Антон собрал для конкурентного анализа по Творим Совершенство (Директ/лендинги).
**How to apply:** Использовать при создании лендингов для ТС, анализе конкурентов, оптимизации рекламы.

## Отдельные лендинги (8):
1. https://florence-total.ru
2. https://total-mia-rf.ru
3. https://florence-parodontoz.ru
4. https://implant-miaclinic.ru
5. https://spb.mia-allon4.ru/
6. https://nasha-stoma-vsezubisrazu.ru
7. https://vsena4-bright-smile.ru/
8. https://orbita-zdorovie.ru

## Страницы на основных сайтах (5):
9. https://zubcenter-spb.ru/allon4
10. https://apelsinstom.ru/prothesis
11. https://viniry.stomagrad.ru/
12. https://neworbita-ao6.ru/
13. https://lp-dentariz-stom.ru/ao4
