---
name: Пробрасывание задач между сессиями
description: Задачи из Bot Dev / DevOps / Home сессий должны автоматически попадать в artvision-data TODO, иначе теряются между аккаунтами
type: feedback
originSessionId: e6a53112-50e0-4652-8b76-65d9f768287a
---
Любая задача, поставленная в не-Ops сессии (Bot Dev, DevOps, Home), должна быть продублирована в `artvision-data/TODO.md` того же контекста — иначе второй аккаунт её не увидит и `/combine` не заберёт.

**Why:** Антон работает с двух аккаунтов (justtrance + adw.artvision.pro). Задачи из Bot Dev сессии жили в `artvision-tg-bot/TODO.md`, но `/combine` запускается чаще всего из Ops контекста — там этих задач не видно. Результат: дубли, потерянные обещания, 36 часов вялой работы за 2-3 дня (инцидент 2026-04-13).

**How to apply:**
1. При получении задачи в Bot Dev / DevOps / Home — записать в **оба** файла: локальный TODO сессии + `artvision-data/TODO.md` с тегом `[session:bot-dev]` / `[session:devops]` / `[session:home]`
2. Формат: `- [ ] Задача [session:bot-dev] [client:X] [result:X] [priority:high] [skill:auto]`
3. `/combine` должен фильтровать по `[session:]` и запускать из нужного cwd
4. При закрытии задачи — отмечать `[x]` в обоих местах (или хук task-router делает это автоматически)
5. Раз в день (09:00 брифинг) — сверять 5 TODO файлов на предмет расходов, мердж через task-router
