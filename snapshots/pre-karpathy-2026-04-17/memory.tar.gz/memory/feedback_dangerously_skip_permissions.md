---
name: dangerously-skip-permissions в алиасах
description: Флаг --dangerously-skip-permissions — это CLI-флаг при запуске, не настройка в settings.json. Алиасы cc-ops/cc-bot/cc-devops обновлены 21.03.2026.
type: feedback
---

`--dangerously-skip-permissions` — флаг командной строки, НЕ настройка в settings.json.
`skipDangerousModePermissionPrompt: true` в settings.json — только пропуск предупреждения при запуске с этим флагом.

**Why:** Антон заметил что пермишены стали спрашиваться — алиасы запускали `claude` без флага.

**How to apply:** Алиасы в `~/.claude/task-router/session-aliases.sh` — все обновлены с `--dangerously-skip-permissions`. Если Антон снова жалуется на пермишены — проверить этот файл первым.
