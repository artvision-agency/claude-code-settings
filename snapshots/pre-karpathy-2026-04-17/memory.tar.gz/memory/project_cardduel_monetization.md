---
name: Card Duel — монетизация и инфра
description: Антон отвечает за монетизацию Card Duel. Стас — код/геймплей. Домен playden.games, VPS 147.45.232.226, Colyseus Docker :3001
type: project
---

**Card Duel** (ранее "Cardwell") — карточная PvP игра.

- **Стас** (@StasMura, Stanislav2014) — код, геймплей, IP 100% его
- **Антон** — монетизация, маркетинг, стратегия платформ
- **Artvision** — стратегическая поддержка

**Why:** Антон явно сказал "за монетизацию проекта я тоже отвечаю" (21.03.2026)

**How to apply:** При задачах по Card Duel — не "отправь Стасу инструкцию", а делай монетизацию сам: регистрации, интеграции SDK, настройка ads, аналитика, submit на платформы. Стасу — только вопросы по коду/серверу.

**Инфра:**
- Домен: playden.games
- VPS: 147.45.232.226 (Colyseus Docker :3001, Nginx proxy)
- Repo: github.com/Stanislav2014/card-duel (private, master)
- Fork: github.com/artvision-agency/card-duel
- Yandex Games: ✅ принят
- 9 билдов: Yandex, TG, CrazyGames, Poki, VK, FB, itch.io, OK, GameDistribution

**Revenue toolbox:** `products/cardwell/revenue-toolbox-2026-03-21.md`
