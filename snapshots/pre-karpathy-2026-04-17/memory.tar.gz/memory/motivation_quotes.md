---
name: motivation-quotes-diary
description: Дневник мотивационных цитат о росте компании, масштабировании и предпринимательстве — читать когда нужен заряд
type: project
originSessionId: b53d45d8-1476-43c9-8957-088af6c8a3e3
---
# Дневник мотивационных цитат

> Мы идём от 511K к 2M и дальше к 5M. Эти цитаты напоминают ЗАЧЕМ и КАК.

---

## Jensen Huang — Будущее работы с агентами

*Источник: @theallinpod, [Instagram](https://www.instagram.com/reel/DWJf1n3kWY2/)*

**Jensen:**
"Everything that's too big, too heavy, takes too long — those ideas are all gone."

**Chamath:**
"You're reduced to creativity. Like, what can you come up with?"

**Jensen:**
"Exactly."

"Now the question is, how do you work with these agents?"

"Well, it's just a new way of doing computer programming."

"In the past, we code."

"In the future, we're going to write ideas, architectures, specifications. We're going to organize teams. We're going to help them define how to evaluate the definition of good versus bad. What does it look like when something is a great outcome? How to iterate with you, how to brainstorm."

"That's really what you're looking for."

"Every engineer is going to have 100 agents."

**Почему это про нас:** Мы уже так работаем — агенты, спецификации, оркестрация. Это не будущее, это наш текущий стек. Конкуренты ещё кодят руками.

---

## Larry Ellison — Вызов общепринятому

*Источник: @financedigg, [Instagram](https://www.instagram.com/reel/DVv2yYKD6-d/)*

Larry Ellison's core advice to entrepreneurs is to challenge conventional wisdom.

He argues that to build a massive company, you must find a "crazy" idea that others aren't doing — because if everyone else is doing it, the opportunity is already gone.

> "Identify Errors: Look for areas where the general consensus is actually wrong."

> "Ignore the 'Crazy' Label: If people think your idea is insane, you might be onto something unique."

> "Execution is Rare: A great idea is only the start; the real value is in the relentless execution."

**Почему это про нас:** AI-агентство без найма программистов, один человек управляет флотом агентов — это и есть "crazy idea" которую рынок пока не понял.

---

## Adam Coffey — Roll-up стратегия

*Источник: @simplyougrow, [Instagram](https://www.instagram.com/reel/DWOsQcVEs3r/)*

Adam Coffey's roll-up strategy shows how value can be created in a predictable, almost mechanical way.

The idea is simple: buy several small businesses earning around $1M EBITDA at low multiples (about 5x), integrate them, cut redundant costs, and run them as one platform. Without chasing growth, basic efficiencies can lift combined EBITDA meaningfully.

The real upside comes from multiple expansion. Small businesses trade cheaply because few buyers can finance or scale them. But once those same cash flows are combined into a $5M+ EBITDA platform, they suddenly attract private equity, strategic buyers, and better debt — pushing valuations to 8x or more.

> "That gap is the arbitrage. Buy low, professionalize, consolidate, and sell into a completely different market."

It's why roll-ups keep working in fragmented, boring industries with stable cash flow: the math, not hype, does the heavy lifting.

**Почему это про нас:** Artvision собирает клиентов из фрагментированного рынка, стандартизирует процессы (Flow, Radar, Scout) и создаёт платформенную ценность. Те же принципы — без покупки бизнесов, через подписочные продукты.

---

## Jeff Bezos — "Releasing the Work"

*Источник: @multiprenur, [Instagram](https://www.instagram.com/p/DW4hZBVE2Kw/)*

Jeff Bezos explained Amazon's powerful internal framework called "Releasing the Work".

> "Good leaders are good at releasing the work. They make the call, set the standard, then trust the team to execute."

This simple philosophy allowed Amazon to move extremely fast, scale from a bookstore to a $2.6 trillion company, and launch dozens of new businesses while staying agile.

It's one of the core reasons Amazon could grow so aggressively for decades.

**Почему это про нас:** Мы буквально это делаем — задаём стандарт (rules, skills, quality gates), делаем call (приоритеты, архитектура), а выполнение передаём агентам. "Release the work" = наш swarm-подход. Не делать руками — оркестрировать.

---

---

## Eric Schmidt — Строить НА AI, а не просто использовать

*Источник: @aikhwarizmi, [Instagram Reel](https://www.instagram.com/reel/DVnDCb_k44G/)*

When Eric Schmidt talks about the future of AI, it's worth paying attention. According to the former Google CEO, the biggest opportunity right now isn't just using AI — it's building products and businesses on top of it.

AI is lowering the barrier to creating software, automating tasks, and scaling ideas faster than ever before. From startups using tools like OpenAI and NVIDIA infrastructure to individuals launching AI-powered apps, the new digital gold rush has already begun.

> "Those who learn how to leverage AI today won't just adapt to the future — they'll help build it."

**Почему это про нас:** Artvision не "использует AI" — мы строим продукты поверх AI (Radar, Scout, Flow, Consilium). Клиенты получают результат, а под капотом — наш стек агентов. Это и есть "building on top of AI", а не просто промпты в ChatGPT.

---

## Татьяна Черниговская — Стресс, поток и творчество

*Источник: ПРОФЕССОР-ДА, [YouTube igrAKVHZ6RE](https://www.youtube.com/watch?v=igrAKVHZ6RE) — «Добиваться успеха. Хорошо ли работать на стрессе»*

### О стрессе и дедлайнах

> «Мой мозг требует адреналина, ему стресс подходит. Приближается дедлайн — у меня нет ни одной буквы. Нечего суетиться заранее, меня должен стресс схватить мёртвой хваткой за глотку. Когда уже завтра утром, выхода нет — тогда я сажусь и за ночь всё пишу.»

> «Я могла бы те же 12 часов потратить за 2 недели до этого. Нет, не могла. Я это всё опробовала. Ничего не выходит.»

### О потоке (ссылаясь на Олега Нестерова)

> «Поток пошёл — это точно. Попал в поток — главное из него не выходи. Не говори „это я потом, сейчас котлеты надо поджарить“. Котлеты в помойку — а из потока не выходить.»

### О том, что думать — это тяжёлая работа (Мамардашвили, Пятигорский)

> «Думать очень сложно. Себя нужно держать в потоке, нельзя шаг вправо, шаг влево. Мысль всё время куда-то бежит, то сюда тащит, то что-то другое в голову лезет. Удержаться в этой речке — большой труд.»

### О научных открытиях (Нильс Бор — Эйнштейну)

> «Ты не мыслишь, ты просто думаешь логически. Удар до удара. Твоё открытие находится в том месте, куда ты даже глаз не поворачивал никогда.»

**Широкое поле ассоциаций важнее отличника:** открытия совершает не пятёрочник, а тот, чья картина мира максимально широка — и работает одномоментно, вся.

### Об ошибке как начале творчества (Боб Дилан)

> «Когда ты начинаешь писать музыку, ты сначала повторяешь учителей. А потом где-то ошибся — и именно в этой ошибке начинается твоё творчество. Ошибка — это красота.»

### Об озарении (aha-эффект, вау-эффект)

> «Если посадить человека и сказать "думай-думай-думай" — ничего не выйдет. Наоборот: бросай всё, погуляй по лесу, слушай музыку. На поверхности ничего, а под поверхностью цунами и бури. Потом — без объявления войны — вдруг как ударит. Всё это время организм работал на задачу, вне контроля сознания.»

### О Перельмане

> «Он опередил математику на несколько столетий. Какая премия, о чём разговор, когда человек берёт такие планки. Он работает в пространстве, где уже неважно, где разговаривают святые, где нет ни столов, где признак отдельно от объекта.»

### О долге в сумасшедшем мире

> «Гордыни поменьше. Мы должны делать то, что мы можем. Нельзя впадать в уныние и считать, что раз апокалипсис за окном, то можно больше ничего не делать. Мы разлагаем не только себя, но и других. Жизнь должна идти.»

**Почему это про нас:**

1. **Работа под дедлайном — нормально.** Если "меня припёрло" = режим продуктивности, не надо винить себя за это. Планируй под свою биологию, а не против неё.
2. **Поток неприкосновенен.** Когда пошло — отменяй всё остальное, включая "важные" мелочи. Котлеты подождут, деплой подождёт, чат подождёт.
3. **Рутина мышления — это труд.** Мысль ускользает постоянно. Если трудно удержаться в задаче — это не слабость, это норма.
4. **Широта > глубина одного навыка.** Мы строим на стыке SEO + AI + продажи + продукты. Это не разбросанность, это то самое "поле ассоциаций" откуда приходят открытия.
5. **Ошибки в продуктах и КП = точки роста.** Не прятать косяки — разбирать, именно там зона творчества.
6. **Озарения приходят в душе и на прогулке.** Не сидеть в кресле до посинения — выйти, переключиться, дать мозгу работать в фоне.
7. **В кризис — делать то, что умеешь.** 2M→5M на фоне "сумасшествия мира" (политика, экономика, AI-революция) — это и есть делать своё дело, не распадаясь.

**Примечание о транскрипции:**
Транскрипт сделан локально через OpenAI Whisper base model (CPU, без GPU). Все 9 цитатных блоков сверены построчно с транскриптом — дословная точность подтверждена. Известный артефакт распознавания: whisper услышал "Гополис" вместо "Мегаполис" (группа Олега Нестерова) — исправлено вручную по фактическому знанию. Возможны другие мелкие артефакты распознавания русской речи base-моделью; при сомнениях — сверяться с оригиналом видео.

*Добавлено: 2026-04-13 (транскрипт whisper base model, 38 мин)*
