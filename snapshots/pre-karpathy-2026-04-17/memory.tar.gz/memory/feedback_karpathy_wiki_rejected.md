---
name: Karpathy LLM Wiki — уже пробовали и отключили
description: 06.04 развернули Karpathy Wiki, 14.04 отключили — 80% дубль memory/rules/skills, отнимал 3-5ч/неделю на поддержку. AutoResearch = 0% (ML-стек не наш). Не возвращаться к Wiki без новой проблемы
type: feedback
source: commit 5648365b2 (2026-04-14), artvision-data/_archive/knowledge-wiki-karpathy/
fetched: 2026-04-17
originSessionId: a640231e-fa5d-4a00-bf1e-4cb9fe33f494
---
## Факт

**06.04 → 14.04**: развёрнули Karpathy Wiki (artvision-data/wiki/ + knowledge/ + hooks inject-knowledge.sh, stop-knowledge-reminder.sh + skill wiki).
**14.04 отключили** коммитом `5648365b2` — "Wiki was 80% duplicate of memory. Moved to _archive/. Frees ~3-5h/week."

Архив: `artvision-data/_archive/knowledge-wiki-karpathy/` (clients, cms, infrastructure, kp-presale, music, products, seo + INDEX.md).

## Почему отключили

1. **80% дубликат** memory/rules/skills — те же facts в двух местах
2. **3-5 часов/неделю** уходило на поддержку (merge между wiki/ и memory/, обновление INDEX.md)
3. **Hypothesis lifecycle** (hypotheses.md в knowledge/*/) не давал uplift поверх feedback_*.md
4. **inject-knowledge.sh** хук добавлял контекст, но rules auto-load уже работает

## Почему

- **Why:** полный цикл внедрения Karpathy Wiki уже пройден в апреле 2026. Результат — отключение как дубль существующей связки
- **How to apply:** если в будущем предлагают "давайте внедрим Karpathy Wiki / persistent knowledge layer" — СНАЧАЛА проверить этот файл. Не возвращаться без НОВОЙ проблемы (конкретная потеря знаний, не решаемая rules/memory/skills)

## AutoResearch (сопутствующий вопрос)

НЕ внедрять. Не наш стек:
- Требует GPU, свою nano-модель (<1B params)
- API Claude/Gemini на объёме 200 запросов/день в 100× дешевле
- Fine-tuning на OpenAI API ($10/модель) закроет ту же задачу без MLOps

Возможный сценарий возврата: масштабирование AIvision до 50+ клиентов с daily GEO-мониторингом.

## Что РАБОТАЕТ вместо Wiki

| Слой Karpathy | Наш аналог | Где |
|---|---|---|
| Raw sources | `clients/*/meetings/`, `raw/` (точечно) | `artvision-data/` |
| Wiki (curated) | `memory/*.md` (135+ файлов) + auto-load | `~/.claude/projects/-Users-antonk/memory/` |
| Schema | `~/.claude/rules/research-to-memory.md` | правила |
| Decisions | `context-log.md` клиентов + git commits | — |
| Quality gates | `factcheck-v2.py` + хуки `post-scp-factcheck` | `~/.claude/hooks/` |
| Ingest | `scripts/link-processor.py`, `ai-news-monitor` | различные скрипты |
| Lint | **НЕТ** — open issue, нужен (scaling cliff 136 файлов) | задача #2 в TODO knowledge-system |

## Реальная дыра автоматики

Есть хуки `auto-memory-suggest.sh`, `post-commit-learning.sh`, skill `ai-evolve` — но **цикл не замкнут**: 110 файлов в learning-queue/ копились с 08.04 без обработки. Фикс — задачи #1-5 в `artvision-data/TODO.md` (knowledge-system section).
