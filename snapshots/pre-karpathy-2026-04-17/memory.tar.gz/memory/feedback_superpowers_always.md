---
name: Superpowers skills — ОБЯЗАТЕЛЬНАЯ маршрутизация по типам задач
description: Жёсткая привязка superpowers skills к типам задач. Пропуск = косяки (расплющенные фото, баги в проде).
type: feedback
---

## Правило: тип задачи → superpowers skill (автоматически)

| Тип задачи | Superpowers (ОБЯЗАТЕЛЬНО) | Пример |
|-----------|--------------------------|--------|
| Новая фича/страница/КП | `brainstorming` → `writing-plans` | Esenina страница, КП клиенту |
| Написание кода | `test-driven-development` | Скрипт, бот, pipeline |
| Фикс бага / "не работает" | `systematic-debugging` | Расплющенные фото, бот падает |
| CSS/визуал/дизайн | `brainstorming` + `verification-before-completion` | Hero фото, шахматка, адаптив |
| 3+ независимых задач | `dispatching-parallel-agents` | TODO с 4+ пунктами |
| "Готово" / деплой | `verification-before-completion` | Скриншот + чеклист ПЕРЕД "готово" |
| После написания кода | `requesting-code-review` | Senior-ревью ловит косяки |

**Why:** Инцидент 2026-03-19 — расплющенные фото Esenina ушли в прод без verification. 5 итераций фиксов вместо 1 потому что brainstorming пропущен. Антон МНОГОКРАТНО просил (2026-03-16, 2026-03-17, 2026-03-19).

**How to apply:**
1. Получил задачу → определи тип → вызови соответствующий superpowers skill ПЕРВЫМ
2. НЕ рационализировать пропуск ("простая задача", "я уже знаю", "быстро поправлю")
3. Для визуальных задач (CSS, дизайн, страницы) — ОБЯЗАТЕЛЬНО verification со скриншотами на 3 breakpoints ПЕРЕД "готово"
4. Custom domain skills (seo-master, presale-kp) вызываются ПОСЛЕ superpowers brainstorming
