---
name: feedback-check-credentials-first
description: ОБЯЗАТЕЛЬНО проверять tokens.json и credentials на наличие доступов ПЕРЕД заявлением "нет доступа"
type: feedback
originSessionId: 8220ba0f-72ba-4953-8f8b-3d8038862265
---
# Проверка доступов — СТРОГОЕ ПРАВИЛО

**Why:** Антон указал что все доступы есть, а Claude заявляет "нет доступа" / "нужен доступ к CMS" не проверив. Это тратит время и раздражает.

**How to apply:**

## БЛОКИРУЮЩЕЕ ПРАВИЛО: ПЕРЕД словами "нет доступа" / "нужен доступ" — ПРОВЕРИТЬ:

1. `tokens.json` — `python3 -c "import json; d=json.load(open('tokens.json')); print([k for k in d])"`
2. `clients/[name]/credentials.md` — если существует
3. `clients/[name]/setup/` — инструкции по настройке
4. `clients/[name]/patches/` — паттерны деплоя (FTP, SSH, MODX)
5. `clients/[name]/config.yaml` — CMS тип, домен

## Типичные ключи в tokens.json:
- `[client].ssh` — хост, порт, user, password
- `[client].modx` — username, password, url (админка)
- `[client].ftp` — FTP доступ
- `yandex.metrika` — токен + counter_id для каждого клиента (avtoworld_counter, vlpco_counter, otido_counter, varikozanet_counters)
- `yandex.webmaster` — токен + user_id
- `topvisor` — api_key
- `gemini.api_key` — работает как PageSpeed API key
- `dataforseo` — login/password (api_login пуст — нужна ручная генерация)

## ИНЦИДЕНТ 2026-04-17: SEO-аудит
Claude заявил "скоры низкие потому что нет API-токенов". Антон: "ищи, все есть". Метрика, Вебмастер, Topvisor, Gemini — ВСЕ были в tokens.json. Behavioral score вырос с 3% до 18% просто подключив существующие токены.

## ANT Partners конкретно:
- FTP деплой через `curl -T` (SSH shell отключен)
- MODX админка есть в tokens.json
- Тесты → artvision.pro, боевой → FTP
