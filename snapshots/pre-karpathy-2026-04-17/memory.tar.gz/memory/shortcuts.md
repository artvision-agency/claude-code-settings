# Быстрые ассоциации (shortcuts)

Пользователь часто пишет короткие слова вместо полных названий.
Claude должен распознавать их мгновенно.

## Клиенты

| Слово | Проект/клиент | Путь |
|-------|--------------|------|
| ант, ant | ANT Partners (юристы) | clients/ant-partners/ |
| варикоз, varikoz, адвертмед | AdvertMed / Варикознет | clients/advertmed-varikozanet/ |
| творим, tvorim, стомат | Творим Совершенство (стоматология) | clients/tvorim-sovershenstvo/ |
| мирулиди, марулиди, mirulidi | Mirulidi Clinic (стоматология, пресейл) | clients/mirulidi-clinic/ |
| отидо, otido | OTIDO (логистика) | clients/otido/ |

## Продукты

| Слово | Продукт | Путь/контекст |
|-------|---------|---------------|
| сканер, scanner | Сканер клиники | products/clinic-scanner/ |
| грид, sitegrid, ретаргет | SiteGrid / ретаргетинговая сеть | products/sitegrid/ |
| айвижн, aivision | AIvision (GEO/AI услуги) | docs/plans/aivision* |
| психо, sales psych | Sales Psychology Analytics | brainstorming, MEMORY.md |

## Инфраструктура

| Слово | Что имеется в виду | Детали |
|-------|-------------------|--------|
| сервак, vps, впс | VPS 80.90.181.152 | Timeweb Cloud, сервер 6670871 |
| бот, тг бот | @avportal_bot | artvision-tg-bot/, Vercel |
| панель, timeweb | Панель Timeweb Cloud | login: sr951557 |
| асана, asana | Asana workspace | Задачи - Artvision |
| хилер, healer | VPS Healer скрипт | scripts/vps_healer.py |

## Поддомены

| Слово | URL |
|-------|-----|
| ант дев, ant dev | https://ant-dev.artvision.pro/ |
| кб, kb | https://kb.artvision.pro/ |
| симметрон | https://symmetron.artvision.pro/ |
| репорты | https://reports.artvision.pro/ |
| аи | https://ai.artvision.pro/ |

## Команда

| Слово | Кто |
|-------|-----|
| андрей | Андрей Киселёв (@PandaCaffe) |
| стас | Стас (madsmile666666@gmail.com) |

## Действия

| Слово | Действие |
|-------|---------|
| синк, sync, пуш | git pull/push всех репо |
| статус, status | /infra-status |
| бекап, backup | Бэкап VPS |
| рой, swarm | Запуск параллельных агентов |
| прокачивай, прокачай, лернинг | Обнови memory/skills из опыта сессии |
| вебмастер | Яндекс.Вебмастер: API проверка, скрипт webmaster-health-check.py |
| tvorims bot, бот творим | @tvorims_bot на VPS (systemd, /opt/tvorims-bot/) |
