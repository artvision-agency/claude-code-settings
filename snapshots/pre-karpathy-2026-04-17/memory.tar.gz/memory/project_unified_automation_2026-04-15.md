---
name: project_unified_automation_2026-04-15
description: Мета-проект 15.04.2026 — TG story outreach + Contact Graph + Notification Dashboard + AI Advisor revival, дедлайн 19-20.04
type: project
originSessionId: 0fa085f7-757e-4f61-81a9-d1f457fe5554
---
# Unified Automation Epic — старт 2026-04-15

**Why:** Антон хочет объединить TG/email/метрики/Asana в единый CRM-граф, автоматизировать outreach по свежим сторис рабочих контактов, возродить AI Advisor и построить локальное окно-дашборд закрытых задач.

**How to apply:** это сквозной проект на неделю. До пн 21.04 — пилот всех 3 эпиков.

## 3 эпика + research

1. **TG Story Outreach** — Telethon на VPS, watcher /10мин, whitelist auto (≥5 переписок/60д + Andrey/Stas), просмотры ТОЛЬКО (без лайков пока), при новом сторис → VLM-анализ → draft в @avportal_bot мне в личку
2. **Unified Contact Graph** — SQLite `~/artvision-data/graph/contacts.db`, импорт Telethon+Gmail+IMAP(dune87)+Asana+meetings, entity resolution LLM, CLI `./graph who`, hook автозаписи
3. **Notification Dashboard + AI Advisor** — macOS окно закрытых задач (стэк после research), EOD-bot 18:00, AI Advisor listener чата команды → классификатор задач → draft с кнопками

## Решения Антона (15.04 22:45)
- Whitelist: авто
- Лайки: НЕТ, только просмотры
- Cron: на VDS
- Research: свобода + строгая оценка
- AI Advisor: тот же репо `~/artvision-tg-bot`, КРИТИЧНО не повторить смерть первого
- Graph storage: SQLite ок

## AI Advisor — hardening (чтобы не умер как первый @avportal_bot)

Прошлые нарушения (из lessons-tvorims-bot.md + feedback_bot_monitoring.md + self-corrections #7):

1. **Inline imports в функциях** → Python shadowing → UnboundLocalError. Перед deploy: `grep -n "^[[:space:]]*import " handlers/*.py`
2. **Правка кода на VPS напрямую** → git-only deploy, запрет SSH-правки
3. **Нет healthcheck** → бот падал 3 дня, 129 рестартов, узнали случайно
4. **Нет алертов при restart loop** → systemd Restart=always RestartSec=10 + healthcheck /5мин → при 3+ рестартах СРАЗУ TG алерт
5. **Memory leak** → авто-рестарт при >200MB
6. **Нет import validation в deploy** → pre-deploy: `python -c "import main"` обязательно
7. **После деплоя не проверяли логи** → 5 минут `journalctl -f` обязательно, паттерны Traceback/Error/Conflict

## Research agents запущены 15.04 22:48
- Dashboard solutions (6+ вариантов) → `/tmp/research_dashboard.md`
- Telethon anti-ban 2026 → `/tmp/research_telethon_antiban.md`
- Entity resolution (dedupe/Splink/LLM) → `/tmp/research_entity_resolution.md`

## TaskCreate #1-8 созданы в этой сессии

## Следующий шаг
Дождаться 3 research → свести в план-факт → начать с Эпика 2 (Contact Graph) как фундамента для остальных.
