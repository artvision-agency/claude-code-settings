---
name: telegram-api-registration
description: Как получить api_id/api_hash на my.telegram.org — решения ошибки ERROR при Create application. Автоприменение при задачах с Telethon, Pyrogram, TDLib.
type: reference
---

# my.telegram.org — Create Application: решения ошибки ERROR

## Проблема
При создании приложения на my.telegram.org форма показывает "ERROR" без деталей.
Это известная массовая проблема (GitHub issues #597, #350, #273 в tdlib/telegram-bot-api).
Telegram намеренно скрывает причину ошибки.

## Корневая причина
Telegram блокирует создание если:
- IP не совпадает со страной номера телефона (VPN, прокси)
- Браузерные расширения (AdBlock, uBlock) блокируют запросы
- Слово "telegram" в названии приложения
- Спецсимволы в Short name
- Слишком много попыток (flood wait)

## Подтверждённые решения (с положительным результатом)

### 1. Мобильный интернет (самое надёжное)
- Открыть my.telegram.org С ТЕЛЕФОНА через мобильный интернет (НЕ WiFi)
- IP мобильного оператора = IP страны номера = совпадение
- Источник: GitHub #597, несколько подтверждений

### 2. Минимальные поля формы
- App title: `Test App` (БЕЗ слова "telegram"!)
- Short name: `testapp` (только строчные a-z + цифры, 5-32 символа)
- URL: ПУСТОЕ
- Platform: **Other** (или Android — попробовать оба)
- Description: одно слово, например `testing`
- Источник: GitHub #350 (aliniko79, pepyakin)

### 3. Отключить VPN + расширения
- Полностью отключить VPN
- Отключить AdBlock / uBlock / все расширения
- Источник: levlam (мейнтейнер tdlib), GitHub #350

### 4. Сменить браузер
- Safari / Firefox / Edge в приватном режиме
- Очистить кеш и куки перед попыткой
- Источник: GitHub #273 ("I used Edge instead of Chrome. It worked.")

### 5. Конкретные рабочие значения полей
- App title: `Chat Bot`, Short name: `chatbot`
- Источник: GitHub #273

## Порядок попыток (рекомендуемый)

1. С телефона через мобильный интернет + минимальные поля
2. Если не сработало — десктоп Safari/Firefox private + без VPN/расширений
3. Если не сработало — подождать 24ч (flood wait) и повторить п.1
4. Крайний случай: другой номер телефона

## Для Антона (номер +79110861888)
- Российский номер → нужен российский IP (без VPN)
- Мобильный оператор МТС/Билайн/Мегафон даёт чистый российский IP

## Источники
- https://github.com/tdlib/telegram-bot-api/issues/597
- https://github.com/tdlib/telegram-bot-api/issues/350
- https://github.com/tdlib/telegram-bot-api/issues/273
- https://appuals.com/telegram-developer-account-error/
- https://core.telegram.org/api/obtaining_api_id
