# ANT Partners — уроки

### Адрес офиса: Саперный пер., 10 (2026-03-17)
**Актуальный адрес:** Саперный пер., д. 10, лит. А, Санкт-Петербург.
**Старый адрес (НЕ использовать):** Льва Толстого, 9, офис 750 (БЦ "Толстой Сквер").
На сайте ant.partners/kontaktyi/ до сих пор старый — нужно обновить.

### Каталоги: реально 0/6 (2026-03-17)
Фактчекинг показал: Яндекс.Бизнес и Google Business НЕТ (ранее ошибочно "есть").
Заявки 17.03: 2GIS ✅, Zoon ✅ (модерация). Остальные не зарегистрированы.

### Деструктивные скрипты = СНАЧАЛА бэкап + dry-run (2026-02-24)
Ошибка: `strip_inline_duplicates.py` удалил 157 секций без бэкапа. ВСЕГДА: git stash → --dry-run → проверить → запустить.

### Шаблон ≠ эталон → сверять ПЕРЕД разработкой (2026-02-24)
master-template.html имел TG-кнопки в price_table и сложные service_cards, а эталон (service-page-APPROVED.html) — простой текст. Сначала читать эталон, потом писать шаблон.

### URL = из sitemap, НЕ из головы (2026-02-24)
ВСЕГДА: `curl sitemap.xml` → маппинг → slug.

### Jinja2: dict['key'] не dict.key для зарезервированных имён (2026-02-24)
`card.items` → dict.items() метод. `card['items']` → ключ словаря.

### Валидатор должен ловить РЕГРЕССИЮ (2026-02-24)
29/29 PASS при 157 удалённых секциях = бесполезный валидатор. Нужно: сравнивать с предыдущей версией.

### Хабовая структура = SEO актив (2026-02-24)
4 хаба (proverki, donachisleniya, riski, spory) → topical authority. Блог/статические = НИКОГДА не трогать.

### Камералка-эталон ВСЕГДА должна быть на test (2026-02-24)
`service-page-APPROVED.html` → `ant.partners/test/service/proverki/kameralnaya-proverka.html`

### Генерация страниц = ТОЛЬКО через generate_page.py (2026-02-24)
НЕ прямой HTML. Pre-Task Protocol обязателен.

### Плоские vs вложенные файлы — загружай ПРАВИЛЬНЫЕ (2026-02-28)
`for_upload_test/` содержит СТАРЫЕ плоские файлы (от 20.02) + НОВЫЕ вложенные (`service/proverki/`).
Генератор пишет в вложенные (по slug = `service/proverki/vyezdnaya-proverka`), плоские НЕ перезаписывает.
**ВСЕГДА** загружать из вложенной структуры + 6 плоских slug'ов (без `/service/`).

### Блог: 2 разных MODX шаблона → CSS injection (2026-02-28)
16 из 17 блог-статей на сломанном шаблоне (0 CSS файлов, 0 Google Fonts).
Камеральная = единственная правильная (8 CSS + Google Fonts).
Фикс: `export_blog_pages.py` — curl + inject Google Fonts + CSS override с !important.
Файлы: `blog/exported/*.html` → загружать на тест как standalone.

### SSH = отключен, только FTP (2026-02-28)
`attorneys@77.222.56.111` — shell disabled ("This account is currently not available").
Работать через `curl -T ... ftp://` с теми же credentials из `tokens.json → ant_partners.ssh`.

### ⚠️ ТЕСТОВЫЙ САЙТ = ARTVISION, НЕ КЛИЕНТ! (2026-02-28)
КРИТИЧЕСКАЯ ОШИБКА: загрузил тестовые файлы на `ant.partners/test/` (сервер клиента).
ПРАВИЛЬНО: `artvision.pro/test/ant-partners/` (наш сервер).
ВСЕ тесты для ВСЕХ клиентов = ТОЛЬКО на серверах Artvision. НИКОГДА на серверах клиентов.
Добавлено в CLAUDE.md проекта и глобальный CLAUDE.md.

### Рабочий поддомен ANT Partners = ant-dev.artvision.pro (2026-03-02)
- **URL:** `http://ant-dev.artvision.pro`
- **VPS path:** `/var/www/dev-ant/public_html/`
- **Nginx:** `/etc/nginx/sites-enabled/dev.ant.partners`
- **server_name:** `dev.ant.partners ant-dev.artvision.pro`
- `dev.ant.partners` DNS НЕ настроен → использовать `ant-dev.artvision.pro`
- `test-ant.artvision.pro` — только HTTP, нет SSL, для статики (`/var/www/artvision/ant-test/`)
- Это MODX-копия (PHP, не статика). `/service/` и `/blog/` через try_files → MODX.
- Страницы загружать и в root, и в `service/` (обе структуры нужны).

### Orphan files при смене slug-структуры (2026-03-02)
При смене slug с `bankrotstvo` на `service/bankrotstvo` генератор пишет в новый путь,
но СТАРЫЙ файл в root остаётся. Нужно вручную удалять orphan-файлы после массовой смены slug.

### Unsplash internal API = curl с Chrome UA (2026-03-03)
Python urllib с коротким User-Agent получает 403. Рабочий вариант:
`curl -s -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36" "https://unsplash.com/napi/search/photos?query=...&per_page=20"`
Фильтровать `plus.unsplash.com` (платные). Скрипт: `download_images.sh`.

### SCP bulk upload = разбивать по директориям (2026-03-03)
`scp -r images/` на 29 директорий обрывается ("Connection closed by remote host").
Решение: цикл `for slug in */; do scp -q $slug/*.jpg ...; done` — 29/29 ok.

### GitHub инструменты для нашего pipeline (2026-03-03)
Из анализа 4 инцидентов за 3 недели, топ решения:
1. **BackstopJS** (6.6k stars) — визуальная регрессия, скриншоты на 3 breakpoints
2. **just** (22k stars) — task runner с зависимостями, принудительный pipeline
3. **GitHub Deployment Protection Rules** — разделение dev/prod окружений
