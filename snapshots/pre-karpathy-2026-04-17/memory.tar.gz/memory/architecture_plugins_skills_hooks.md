---
name: architecture_plugins_skills_hooks
description: Когда использовать скилл, хук, скрипт, cron — правило выбора по типу задачи + архитектура системы
type: reference
---

## Простое правило выбора

| Когда | Инструмент |
|-------|-----------|
| Ты ГОВОРИШЬ что сделать | **Скилл** |
| Должно сработать САМО | **Хук** |
| Должно работать БЕЗ СЕССИИ | **Cron / LaunchAgent** |
| Тяжёлая логика (парсинг, HTTP) | **Скрипт** (вызывается скиллом или хуком) |

### Комбинации
- **Чисто скилл** — творческая работа (КП, SEO, стратегия). Каждый раз уникально.
- **Скилл + скрипт** — повторяемое действие + контекст. Скрипт делает, скилл подсказывает аргументы.
- **Хук** — защита от ошибок. Пользователь не должен помнить.
- **Cron + скрипт** — регулярные задачи без сессии.

### Примеры по процессам

| Процесс | Инструмент | Причина |
|---------|-----------|---------|
| Деплой HTML | Хук | Авто перед scp |
| Фактчек по запросу | Скилл + скрипт | По триггеру |
| Lint после Edit | Хук | Фоном |
| Экспорт чата TG | Скилл + скрипт | По запросу |
| КП для клиента | Скилл | Нужен мозг |
| Мониторинг бота | Cron + скрипт | Без сессии |

## Архитектура сущностей

| Сущность | Что это | Когда срабатывает | Где живёт |
|----------|---------|-------------------|-----------|
| **Rules** | Характер, запреты, стиль | Загружаются ВСЕГДА в system prompt | `~/.claude/rules/*.md` |
| **Hooks** | Shell-автоматика (lint, блок, напоминание) | На СОБЫТИЕ (Edit, Write, Bash, Stop) | `~/.claude/hooks/*.sh` + settings.json |
| **Skills** | Пайплайн, рецепт — КАК делать | По ЗАПРОСУ (ручной или триггер хука) | `~/.claude/skills/*/SKILL.md` |
| **Agents** | Исполнитель — КТО делает | Из скилла или напрямую через Agent tool | Встроены в CC (subagent_type) |
| **Plugins** | Пакет (скиллы + agents + rules) | Подключаются один раз в settings.json | `~/.claude/plugins/cache/` |

## Superpowers vs обычные скиллы

**НЕ дублируют.** Superpowers = процесс (КАК работать), обычные = домен (ЧТО делать).

| Superpowers | Обычный аналог | Разница |
|-------------|---------------|---------|
| `verification-before-completion` | `/verification-loop` | Логика "всё учёл?" vs техника "build/lint/test" |
| `requesting-code-review` | `/code-review` | Шаблон запроса vs само ревью |
| `dispatching-parallel-agents` | `/swarm` | Принцип разделения vs конкретный pipeline |

**Порядок:** superpowers:brainstorm → skill:план → superpowers:TDD → skill:код → /code-review → /verification-loop → superpowers:verification

## Flow проверки кода (автотриггеры)

```
Edit → post-edit-lint (lint) → post-edit-autotest (тесты?) → post-edit-skill-trigger:
  3+ файлов бота    → /bot-audit
  5+ кодовых файлов → /code-review
  10+ файлов        → /code-audit
  15+ изменений     → /verification-loop

git commit → pre-commit-check (синтаксис + pytest = БЛОК если fail)
git push   → pre-push-summary (что летит)
scp/deploy → post-deploy-smoke (healthcheck напоминание)
```

## Мёртвые хуки (файл есть, не подключены) — ревизия 21.03.2026

- `context-monitor.sh` — удалить (superpowers /strategic-compact лучше)
- `post-frontend.sh` — удалить (заменён post-edit-autotest + post-generate-validate)
- `sync-all-repos.sh` — удалить (дубль stop-sync-all.sh)

## Проблема: 16 из 25 инструментов не применялись

**Why:** работает ТОЛЬКО то, что на хуках. Всё что требует "вспомнить и вызвать" — мёртвый груз.
**How to apply:** новые проверки = ВСЕГДА хук-триггер, не надежда что Claude вспомнит.
