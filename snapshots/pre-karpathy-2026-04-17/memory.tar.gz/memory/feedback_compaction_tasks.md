---
name: After compaction — TaskCreate for all pending items
description: After session compaction/resume, MUST parse summary for pending tasks and create TaskCreate for each. Text promise ≠ tracked task.
type: feedback
---

After compaction/resume, MUST parse the summary for ALL pending items and create TaskCreate for each one IMMEDIATELY.

**Why:** On 2026-03-23, compaction summary contained "need to do git pull on VPS" and "remaining combain tasks" — but these were just text, not TaskCreate. They were never executed. User caught it and asked why I "lied" about continuing work.

**How to apply:**
1. When session resumes after compaction → FIRST action: find "Pending Tasks" section in summary
2. Every bullet in Pending Tasks → TaskCreate
3. Every "need to", "also", "remaining" in summary → TaskCreate
4. A promise in text ("I'll do X after sync") must become TaskCreate THE MOMENT it's made — don't rely on memory
5. This applies to BOTH compaction summaries AND normal conversation — if you say you'll do something, track it
