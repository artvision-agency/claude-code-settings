---
name: Домен Avto.World
description: Правильный домен клиента avto.world — с точкой, не .ru и не слитно
type: project
originSessionId: 8220ba0f-72ba-4953-8f8b-3d8038862265
---
# Avto.World — правильный домен

**Правильно:** `avto.world`
**Неправильно:** ❌ `avtoworld.ru`, `avtoworld.com`, `avto-world.ru`, `autoworld.ru`

## Where

- Папка клиента: `clients/avtoworld/` (слитно — историческое)
- Домен сайта: **`avto.world`** (с точкой)
- В `plan-m3-full-2026-04.md` явно указано: "Полный план avto.world"
- Брендовые запросы: `"avto.world"` — позиции 1-3

## Why

Я дважды ошибся за сессию 2026-04-17 (писал avtoworld.ru в предложениях). Антон: "опять ошибка с доменом проекта".

## How to apply

Перед ЛЮБЫМ упоминанием сайта Avtoworld в скриптах/аудитах/тестах — сверить с этим файлом. Папка слитно, домен через точку.
