---
name: Roman Mebel — клиент и бренд
description: Роман Кустов представляет Roman Mebel + Burenie-SKV. Бренд IncomeSite (НЕ Artvision) во всех КП и документах
type: project
---

**Роман Кустов** — клиент, представляет ДВА бизнеса:
1. **Roman Mebel** — mf-kupe.ru (шкафы-купе) + legkomarket.ru (готовая мебель)
2. **Burenie-SKV** — burenie-skv.ru (бурение скважин, активный клиент 84K/мес)

**Бренд:** Все КП и документы для Романа пишем от **IncomeSite**, НЕ от Artvision.

**Why:** Роман пришёл через burenie-skv (существующий клиент). Работа идёт под брендом IncomeSite.

**How to apply:** При создании/редактировании любых КП, отчётов, договоров для Романа Кустова (Roman Mebel или Burenie-SKV) — использовать бренд IncomeSite. Проверять все упоминания Artvision → заменять на IncomeSite.

**КП отправлено Роману 23.03.2026** (PDF + HTML с брендом IncomeSite)

**КП (последняя версия 23.03.2026):**
- HTML: `clients/roman-mebel/kp/roman_mebel_kp.html`
- PDF: `clients/roman-mebel/kp/roman_mebel_kp.pdf`
- Деплой: artvision.pro/roman-mebel/
- Контакт: romankoustov@yandex.ru
- Тарифы: Старт 80K, Рост 100K, Максимум 120K/мес
