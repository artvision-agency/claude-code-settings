---
name: TaskCreate всегда по умолчанию
description: Любая задача/pending item из разговора, TODO, meeting notes, summary — СРАЗУ TaskCreate. Без напоминания, без ожидания команды "туду"
type: feedback
originSessionId: da718979-4875-4499-88a9-350c4dcacbf5
---
TaskCreate отражать ВСЕГДА и по умолчанию. Любая встреченная в разговоре задача (из git log, meeting notes, TODO.md, summary после compaction, устного запроса Антона) — СРАЗУ создаётся через TaskCreate, без ожидания команды "туду" или "tasklist".

**Why:** Антон повторно (14.04) настаивал: "TODO/TaskCreate отражать ВСЕГДА! Пытаюсь сделать чтобы ты по умолч делал". Ранее были случаи когда задачи терялись между сессиями и после compaction (см. self-corrections.md #8, #11).

**How to apply:**
- При старте сессии: pending из TODO.md → TaskCreate батчем
- При чтении meeting notes / созвонов: каждая задача из таблицы → TaskCreate
- При разговоре: обещание/действие в тексте Антона → TaskCreate сразу
- После compaction/resume: summary → TaskCreate для каждого pending item
- При создании задач в TODO.md: параллельно TaskCreate в сессии
- НЕ ждать команды "туду"/"комбайн"/"тасклист" — это дефолт
