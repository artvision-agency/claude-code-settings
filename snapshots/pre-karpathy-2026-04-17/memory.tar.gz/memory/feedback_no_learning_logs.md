---
name: No learning logs in session
description: Never show continuous-learning evaluate-session output in chat — Антон не хочет видеть эти логи
type: feedback
---

НЕ показывать логи continuous-learning в сессии.

**Why:** Антон считает это мусором в выводе — "не показывай continues-learning логи в сессиях!"
**How to apply:** evaluate-session.sh пишет в /tmp/ вместо stdout. Если появятся новые learning-хуки — тоже silent.
