# Хуки и конфигурация — уроки

### Hooks с `read -p` не работают в Claude Code (2026-02-26)
Хуки Claude Code **не имеют stdin**. exit 0 (ок), exit 1 (предупреждение Claude видит), exit 2 (блок).

### Два уровня settings.json — глобальный и проектный (2026-02-26)
- **Глобальный** (`~/.claude/settings.json`): минимальные хуки, работают ВЕЗДЕ
- **Проектный** (`artvision-data/.claude/settings.json`): полные хуки, только В проекте
- PostToolUse lint → global. PostToolUse client-html-validate → project only.

### Зеркалирование: ВСЕГДА проверять diff (2026-02-26)
`diff <(ls ~/.claude/hooks/) <(ls ~/artvision-data/.claude/hooks/)` после каждого изменения хуков.

### post-client-html-validate.sh — НЕ ПРОПУСКАТЬ (2026-02-24)
Проверяет бренд-цвета, H2≥3, CTA, телефон, размер <500KB. Исправить ДО коммита.

### Exit codes хуков
- exit 0 = тихо (всё ок)
- exit 1 = показать вывод Claude (предупреждение)
- exit 2 = заблокировать операцию

### macOS grep -c баг
`grep -c` без совпадений возвращает пустую строку + exit 1. Фикс: `if [ -z "$VAR" ]; then VAR=0; fi`
