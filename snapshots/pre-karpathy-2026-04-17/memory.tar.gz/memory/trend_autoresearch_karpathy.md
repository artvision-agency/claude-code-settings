---
name: trend_autoresearch_karpathy
description: AutoResearch by Karpathy — open-source фреймворк для автономной AI-оптимизации. Применимо к нашим продуктам с численной метрикой (SEO, лендинги, cold outreach, Claude Code skills)
type: reference
source: https://github.com/karpathy/autoresearch
fetched: 2026-04-17T12:00:00Z
fetched_via: WebSearch
confirmed_by:
  - https://github.com/karpathy/autoresearch
  - https://venturebeat.com/technology/andrej-karpathys-new-open-source-autoresearch-lets-you-run-hundreds-of-ai
  - https://thenewstack.io/karpathy-autonomous-experiment-loop/
  - https://www.datacamp.com/tutorial/guide-to-autoresearch
  - https://youtu.be/ksr5n_EmT_g (Владимир Карпухин, 11.04.2026)
originSessionId: 8308712b-5546-47a9-b4b0-8d848e20e9b7
---
## Факт (CONFIRMED, ≥3 источника)

- **Что:** open-source фреймворк Andrej Karpathy — агент автономно крутит ML-эксперименты, оставляет только улучшения метрики
- **Релиз:** 7 марта 2026
- **Популярность:** 53.5k ⭐ / 7.4k forks на 24.03.2026
- **Размер:** один файл ~630 строк Python (nanochat-based, только PyTorch)
- **Режим:** 5-минутный цикл обучения → ~12 экспериментов/час → ~100 за ночь
- **Кейс Карпати:** агент на nanochat за 2 дня = ~700 экспериментов, ~20 реальных улучшений

## 3 обязательных условия для применения

1. **Fast feedback loop** — метрика считается за минуты, не дни
2. **Numerical metric** — численная, объективная (не "красиво/некрасиво")
3. **API access** — агент может читать/писать объект оптимизации

## Структура репо AutoResearch

```
program.md  — правила/ограничения для агента
tests/      — тестовый контур
judge.py    — скрипт-оценщик (считает метрику)
```

## Применимость к Artvision

### Прямо подходит (метрика + feedback + API):

| Продукт | Метрика | Feedback | Комментарий |
|---------|---------|----------|-------------|
| **Лендинги клиентов** | Lighthouse / LCP / CLS | <1 мин на page | Прямой кейс из видео: 61→100 за 13 итераций |
| **Cold outreach (BluMart/Atribeaute)** | Open rate / reply rate | дни | Нужен A/B при массе писем |
| **SEO Pipeline (Artvision Flow)** | Позиции Топвизор / CTR SERP | дни-недели | Медленный feedback, но метрика численная |
| **AIvision (Artvision Radar)** | % upvotes AI-поиска | минуты | Feedback быстрый — можно пробовать |
| **Claude Code skills** | % успешных runs | сессия | Karpathy сам этот кейс показывает |
| **Бот опроса @tvorim_opros_bot** | completion rate + avg_score | дни | Малый объём пациентов → слабый feedback |

### Плохо подходит:

- Дизайн КП (субъективная оценка)
- YouTube thumbnails (то же)
- Всё без численной метрики

## Риски (из видео)

**Paperclip problem:** агент может удалить контент чтобы улучшить метрику, если не поставить жёстких ограничений в `program.md`. Пример: "удалил тяжёлые картинки → Lighthouse 100, но страница пустая".

## Применимость-Артвижн: рекомендация

**Первый MVP (самый быстрый feedback):**
- Лендинги на Vercel/Tilda → Lighthouse CI → 13 итераций → +30-40 points
- Cold email генератор для outreach (BluMart uphold) → open rate метрика

**Не стартовать на:**
- Бот опроса (пациентов мало, шум > сигнал)
- SEO (feedback недели)
