---
name: reference-openclaw
description: OpenClaw — open-source AI-агент с автоматической памятью. Референс для улучшения нашей memory-системы.
type: reference
---

## OpenClaw — референс для memory-системы

**Что:** Open-source AI-агент (247K+ GitHub stars), создан Peter Steinberger (Австрия)
**Сайт:** openclaw.ai | docs.openclaw.ai
**Ранее:** Clawdbot → Moltbot → OpenClaw

### Ключевая фича: двухточечная автоматическая память
1. **Before response** — автоматически ищет релевантные воспоминания из прошлых сессий
2. **After response** — автоматически извлекает и сохраняет "durable knowledge"

### Плагины памяти
- **Mem0** (mem0.ai) — persistent memory с auto-recall и auto-capture
- **Supermemory** (github: supermemoryai/openclaw-supermemory) — long-term memory
- **Memori Labs** — плагин для OpenClaw gateway (март 2026)

### Что мы взяли
- Stop-хук `auto-memory-suggest.sh` — аналог "after response" capture
- Формат хранения совпадает: Markdown + YAML на диске, прозрачно для пользователя

### Отличительные преимущества OpenClaw (чего нет у нас)
1. **Мультиканальный gateway** — один агент на WhatsApp + Telegram + Discord + iMessage + email одновременно. У нас: отдельный бот для TG, отдельная сессия Claude Code
2. **Heartbeats** — агент сам инициирует действия по расписанию без запроса пользователя (напоминания, проверки, follow-ups). У нас: cron + LaunchAgents (похоже, но менее гибко)
3. **Persona onboarding** — при первом запуске агент проводит интервью и строит профиль пользователя. У нас: профиль собирается постепенно через memory/user
4. **Self-hosted, 100% локально** — данные никуда не уходят, даже AI inference можно через local LLM (DeepSeek, Llama). У нас: Claude Max = облако Anthropic
5. **Plugin ecosystem** — сторонние плагины (Mem0, Supermemory, Memori Labs) расширяют memory. У нас: только файловая система + хуки
6. **Адаптация к привычкам** — не просто хранит факты, а изучает ПАТТЕРНЫ поведения (когда пользователь активен, какие задачи предпочитает, стиль общения). У нас: `interaction-patterns.md` + `shortcuts.md` (ручное)
7. **247K stars за 4 месяца** — viral adoption, активное community, быстрая эволюция

### Что ещё можно взять
- Auto-recall перед ответом (аналог SessionStart с semantic search по memory)
- Semantic search по memory вместо линейного чтения MEMORY.md
- Плагинная архитектура для memory (Mem0-подобная)
- Heartbeats → расширить наши cron до proactive agent actions
- Persona onboarding → автоматизированный `/new-session-interview` при первом контакте
