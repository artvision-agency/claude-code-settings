# Claude Memory — Artvision

## ГЛАВНАЯ ЦЕЛЬ: 2M → 5M RUB/month

**Установлена:** 2026-02-06, **расширена до 5M:** 2026-03-08
**Текущее подтверждённое:** **511,500 RUB/мес** (6 клиентов) — обновлено 2026-03-21
**Milestone 2M:** Q2 2026 (июнь) | **Milestone 5M:** Q1 2027
**Полный план:** `docs/plans/2026-03-08-revenue-2-5m-plan.md`
**СКВОЗНОЙ ПРИНЦИП:** Зависимость клиента → recurring revenue. Подписки, абонентки, инфра у нас.

### 4 столпа дохода:
1. **Агентство** (40%, цель 2M) — upsell, возврат, новые клиенты
2. **Продукты** (30%, цель 1.5M) — AIvision, Structural, Artssistant, ArtSync
3. **Партнёрства** (20%, цель 1M) — Dental-Experts, Richelist, white-label
4. **Пассивный** (10%, цель 500K) — музыка, шаблоны, affiliate

### Обязательства Claude:
- Минимум 3 раза в день предлагать действия каждому (Asana чекбоксы)
- Всегда учитывать touchpoints с клиентами
- Итератор: не останавливаться пока цель не достигнута

## Ключевые файлы
- `/Users/antonk/artvision-data/PROJECTS.md` — **SOURCE OF TRUTH**, единый обзор всех проектов, клиентов, продуктов. Читать ПЕРВЫМ.
- `/Users/antonk/artvision-data/` — основной репо
- `products/ROADMAP-2026-Q1.md` — 4 продукта, цель 2.3M к дек 2026
- `products/cardwell/revenue-toolbox-2026-03-21.md` — Card Duel монетизация
- `schedule/reports-invoices.json` — расписание отчётов/счетов
- `processes.md` — все процессы
- `revenue-goal.md` — полная стратегия
- `client-revenue.md` — доходы по клиентам
- `clients/kamey/presale/kp/cameo_kp.html` — эталонный дизайн КП

## Доступ к почте через Playwright
- **dune87@yandex.ru** — почта Антона, залогинена в Chrome (Yandex Mail)
- Chrome нужно закрыть перед запуском Playwright (`pkill -f "Google Chrome"`)

## Google Drive автоматизация → `google_service_account.md`
- **Service Account:** `seo-bot@silent-album-187415.iam.gserviceaccount.com`
- **Ключ:** `/Users/antonk/Desktop/_archive_2026/silent-album-187415-de016a15a29f.json`
- Без 2FA/пароля — аутентификация через private key
- ПЕРВЫЙ вариант для Google Drive/Docs (до Playwright/OAuth)

## Удалённые режимы → `claude-code-remote.md`

## Индекс файлов памяти

### Основные:

| Файл | Содержимое |
|------|-----------|
| `products-status.md` | ArtSync, AIvision, Card Duel, PolyTrends, Artssistant, EMD Network, Direkt-Radar |
| `product_artsistant.md` | Artssistant — цифровой ассистент для бизнеса, НЕ "бот" |
| `product_artsync.md` | ArtSync — анализ переговоров (ранее Sales Psychology) |
| `clients-status.md` | Все клиенты: платящие (6), presale (BluMart, UNO Trans, Mirulidi, Roman Mebel), СТОП, бренд |
| `accounts.md` | Команда, Asana GID, Claude Max, TG контакты, сервисы |
| `revenue-goal.md` | Стратегия 2M→5M |
| `infrastructure.md` | VPS, сервисы, история миграции |
| `claude-code-remote.md` | 4 режима работы Claude Code |
| `kp-deploy.md` | Деплой КП на artvision.pro |
| `interaction-patterns.md` | Стиль общения Антона, красные флаги |

### Уроки (разбиты по темам):

| Файл | Содержимое |
|------|-----------|
| `lessons.md` | Общие: workflow, данные, инструменты |
| `lessons-frontend.md` | HTML, CSS, валидация, КП |
| `lessons-modx.md` | MODX CMS, SVG, FTP, VersionX |
| `lessons-ant-partners.md` | ANT Partners генератор, шаблоны, SEO |
| `lessons-hooks.md` | Хуки, settings.json, зеркалирование |
| `lessons-symmetron.md` | PDF перевод, шрифты, LLM парсинг |
| `lessons-suno.md` | Suno AI Music: Mashup, Extend, pipeline |
| `lessons-tvorims-bot.md` | @tvorims_bot: баги (shadowing import), деплой, архитектура канала |
| `competitor-analysis.md` | Конкуренты artvision.pro: 11 агентств |
| `tvorim_competitor_landings.md` | 13 конкурентных лендингов стоматологий СПб для ТС |

### Прочее:

| Файл | Содержимое |
|------|-----------|
| `legal-divorce.md` | Правовые заметки |
| `service-registration.md` | Регистрация сервисов |
| `citydrive-dispute.md` | Спор с Ситидрайв |
| `yandex-direct-2026.md` | Яндекс Директ заметки |
| `shortcuts.md` | Ассоциации команд |
| `feedback_factcheck_after_parsing.md` | ОБЯЗАТЕЛЬНЫЙ фактчекинг после ЛЮБОГО парсинга — Shopstat ≠ бесплатный API |
| `feedback_bot_monitoring.md` | ОБЯЗАТЕЛЬНЫЙ мониторинг для КАЖДОГО production бота — healthcheck + auto-restart + алерты |
| `feedback_context_log.md` | ОБЯЗАТЕЛЬНЫЙ context-log.md для каждого клиента — хук + ручные записи решений |
| `feedback_critical_thinking.md` | ВСЕГДА критический разбор идей Антона: за/против, к какому продукту, варианты |
| `feedback_session_start_tasks.md` | КРИТИЧЕСКИЙ: TaskCreate АВТОМАТОМ при старте КАЖДОЙ сессии, БЕЗ напоминания |
| `feedback_test_messages.md` | При отправке в TG/email клиенту — ОБЯЗАТЕЛЬНО помечать как тестовое |
| `feedback_vacancy_upsell.md` | При увольнении сотрудника клиента — предлагать размещение вакансии как upsell |
| `feedback_advertmed_no_labels.md` | AdvertMed (субподряд): НЕ использовать Artvision [Product] лейблы в материалах |
| `feedback_auto_swarm.md` | Автоматически разбивать задачи на параллельных агентов — не ждать команду "рой" |
| `feedback_auto_agent_decisions.md` | Автономные решения: когда агенты, когда superpowers, когда сам — без вопросов |
| `feedback_quality_over_tokens.md` | Качество ВАЖНЕЕ экономии токенов — не срезать углы, время дороже |
| `feedback_account_switch_alert.md` | Предлагать переключение аккаунта за 5% до лимита (на 95%) |
| `feedback_weekly_task_format.md` | Формат еженедельного отчёта задач — таблица по дням, исполнитель, проект, TG |
| `feedback_self_improvement_loop.md` | ПОСТОЯННЫЙ цикл самосовершенствования: результат↔цель → ревью → rules/ → skills/ |
| `feedback_superpowers_always.md` | ОБЯЗАТЕЛЬНО superpowers skills перед ЛЮБОЙ задачей — brainstorming, TDD, verification |
| `feedback_kp_client_history.md` | ОБЯЗАТЕЛЬНО перед КП найти ВСЮ переписку с клиентом (TG, email, meetings, Asana, Drive) |
| `telegram-api-registration.md` | Получение api_id/api_hash на my.telegram.org — решения ошибки ERROR, порядок попыток |
| `trend_webmcp.md` | WebMCP (W3C, Google+MS) — стандарт для AI-агентов, Chrome 145+, связь с AIvision/GEO |
| `feedback_marker_keywords.md` | Маркерные ключи = разные кластеры даже с одним корнем. Коммерческие vs инфо. Перелинковка усиливает |
| `feedback_kp_relevance.md` | СТРОГО проверять релевантность кластеров/конкурентов нише клиента. Международная логистика ≠ локальные переезды |
| `project_employee_management_system.md` | Система управления сотрудниками: голос→Asana→Claude верификация→отчёт 19:30 МСК |
| `google_service_account.md` | Google Drive без 2FA: SA ключ, email, рабочий код, стратегия эскалации |
| `reference_openclaw.md` | OpenClaw — open-source AI-агент, референс для memory (auto-capture, Mem0, плагины) |
| `feedback_check_systems_first.md` | ОБЯЗАТЕЛЬНО проверять системы (СБИС, CRM, почта) перед автоматизацией — залогинен ли, работает ли |
| `feedback_kp_standards.md` | Стандарты КП: калькулятор услуг, кликабельные источники, динамика оборотов, цель 100-300K/мес |
| `reference_video_storage.md` | Временное хранение видео: Google Drive + Яндекс.Диск (два места) |
| `feedback_no_client_internals_in_kp.md` | НИКОГДА не показывать внутрянку клиента в КП — арбитраж, финансы, HR, долги |
| `feedback_always_ask_before_launch.md` | ВСЕГДА показать список задач и спросить подтверждение перед запуском работы |
| `feedback_plan_fact_format.md` | План/факт: фиксация целей в начале сессии, таблица сверки в конце |
| `feedback_session_menu_format.md` | Старт сессии: таблица задач (проект, задача, дедлайн) + меню действий ВМЕСТЕ |
| `feedback_dangerously_skip_permissions.md` | --dangerously-skip-permissions = CLI флаг, не settings.json. Алиасы cc-* обновлены 21.03 |
| `architecture_plugins_skills_hooks.md` | Архитектура: plugins vs skills vs rules vs hooks vs agents. Карта пересечений, flow, автотриггеры |
| `project_cardduel_monetization.md` | Card Duel: Антон = монетизация, Стас = код. playden.games, VPS 147.45.232.226, Yandex Games принят |
| `feedback_read_project_folder_first.md` | ОБЯЗАТЕЛЬНО `ls`/`find` папку проекта перед любой задачей — знать что уже есть (ассеты, версии, VPS) |
| `feedback_cameo_design_standard.md` | КП CAMEO (kamey.ru) = эталонный дизайн для всех КП и отчётов Artvision |
| `feedback_check_credentials_first.md` | ОБЯЗАТЕЛЬНО проверять tokens.json и credentials ПЕРЕД заявлением "нет доступа" |
| `feedback_competitor_first_then_gap.md` | В КП СНАЧАЛА конкуренты, ПОТОМ разрыв клиента. Не критиковать напрямую |
| `feedback_cro_thinking.md` | ВСЕГДА мыслить CRO-принципами: показать результат вместо вопроса, минимум кликов |
| `feedback_daily_team_news.md` | Каждый день отправлять новости о новых инструментах в групповой чат TG |
| `feedback_deploy_urls.md` | ВСЕГДА давать полные кликабельные URL (https://...) при деплое |
| `feedback_kp_b2b_context.md` | ОБЯЗАТЕЛЬНО учитывать B2B/B2C специфику бизнеса клиента во ВСЕХ КП |
| `feedback_kp_source_links.md` | ВСЕ данные в КП — прямые ссылки на конкретные страницы источников (не главную) |
| `feedback_screenshot_xyz.md` | screenshot.xyz — сервис скриншот-аналитики с API, мы использовали ранее |
| `feedback_table_format.md` | Задачи/результаты/прогресс ВСЕГДА таблицей с отметками, не списком |
| `feedback_test_then_save_skills.md` | Новые знания в скиллы ТОЛЬКО после тестирования и сравнения с исходной задачей |
| `personal_kids_school.md` | Оплата школы (Адаинкидс 6300/мес до 3-го числа) и садика (до 25-го) — напоминания cron |
| `reference_google_drive_materials.md` | Общая папка Google Drive для материалов от клиентов/команды |
| `user_vpn.md` | Антон использует Ultima VPN на телефоне |
| `user_crypto_bybit.md` | Bybit P2P: RUB→USDT, контакт Юрий Хаит, небольшие суммы |
| `allen_income_streams_analysis.md` | Allen 10 Streams × AI: ТОП-3 (infopreneuring, SaaS, licensing) + action plan к 2M |
| `active-tasks.md` | Активные задачи и статусы (обновляется каждую сессию) |
| `deliverables.md` | Готовые результаты, URL, деплои, скрипты |
| `feedback_screaming_frog.md` | Screaming Frog SEO Spider — ОБЯЗАТЕЛЕН для краула, CLI headless доступен |
| `client_roman_mebel.md` | Roman Mebel + Burenie-SKV = Роман Кустов. Бренд IncomeSite (НЕ Artvision!) |
| `project_blumart_reviews.md` | BluMart — активный проект ORM (отзывы), 25/мес март, до 70/мес далее |
| `feedback_dashboard_workflow.md` | Dashboard data-first: JSON→factcheck→render. URL validation before insert. 1 dashboard=1 session |
| `feedback_no_new_templates.md` | ЗАПРЕТ создавать новые шаблоны — только копировать существующие со страниц сайта |
| `motivation_quotes.md` | Дневник мотивационных цитат — Jensen Huang, Larry Ellison, Adam Coffey — рост и масштабирование |
| `client_zakvaski_rus.md` | Закваски.рус (Puratos) — reactivation 14.04.2026, Наталья Колоскова, правки Tilda + упрощение визуала |

## Контекст между сессиями — ИНФРАСТРУКТУРА (2026-03-12)

**Проблема:** потеря ~18 часов/мес из-за повторения решений и забытых договорённостей.

**Решение — 4 файла в каждой папке клиента:**
1. `CLAUDE.md` — правила, бренд, CMS, запреты (создано для 6 клиентов)
2. `context-log.md` — лог действий и решений (хук `post-client-context-log.sh`)
3. `meetings/` — саммари встреч
4. `patches/` — ошибки и уроки

**Хук:** `~/.claude/hooks/post-client-context-log.sh` — PostToolUse(Edit/Write) → добавляет запись.
**Правило:** Pre-Task Protocol в `kp-brand.md` — читать context-log ПЕРВЫМ.

| `project_atribeaute_outreach_monday.md` | КП готово, НЕ отправлять до подтверждения Антона в понедельник 23.03 |
| `reference_telethon.md` | Telethon MTProto: session, API keys, скрипт экспорта чатов, ID чатов клиентов |
| `reference_tg_auto_capture.md` | Авто-фиксация ответов в TG: tg-send-tracked + listener + responder + LaunchAgents, classify+archive+auto-clarify |
| `feedback_compaction_tasks.md` | После compaction/resume — ОБЯЗАТЕЛЬНО TaskCreate для каждого pending item из summary |
| `client_mirbir.md` | МирБир: основной оборот через ИП (не публикуется), 142 млн ООО = часть бизнеса |
| `feedback_no_smoothing.md` | НИКОГДА не сглаживать углы — честно о проблемах, потерях, ограничениях |
| `feedback_no_invented_deadlines.md` | НИКОГДА не выдумывать дедлайны/поля Asana — спрашивать у постановщика |
| `feedback_no_hallucinations.md` | НИКОГДА не выдумывать CLI флаги, фичи, продукты. Проверять --help/docs ПЕРЕД рекомендацией |
| `feedback_artvision_naming.md` | ВСЕГДА писать artvision.pro (маленькая буква + .pro) — никогда Artvision/ARTVISION |
| `feedback_model_downgrade_alert.md` | ВСЕГДА алертить при даунгрейде модели (Opus→Sonnet/Haiku) на ЛЮБОМ аккаунте |
| `feedback_white_screen_debug.md` | Белый экран + 200 OK = проверять HTML-валидность ПЕРВЫМ, не HTTP-статус |
| `feedback_reviews_logic.md` | ORM отзывы: проверять логику текста, не контрить возвраты/мошенничество отзывами |
| `feedback_factcheck_autofix.md` | После factcheck CRITICAL — автофикс битых URL без вопросов, цикл factcheck→fix→re-check |
| `personal_housing.md` | Жильё: Каменноостровский 1-3 кв.39 = собственность+ипотека. Верности 6 = только прописка |
| `feedback_no_free_month_kpi.md` | НИКОГДА не обещать бесплатный месяц или KPI в договоре в КП |
| `feedback_no_cliches.md` | НИКОГДА не писать продающие клише — только конкретный живой язык |
| `feedback_kp_narrative.md` | ВСЕ КП: диагноз→последствия→решение. Крупный текст, формальный тон, без давления, быстрое доверие |
| `project_hh_leadgen.md` | HH-Leadgen (Artvision Leads) — парсер hh.ru вакансий для лидогенерации, MVP запущен |
| `trend_llm_wiki_karpathy.md` | LLM Wiki (Karpathy/Huryn) — knowledge architecture, decision journal, quality gates. Реализовано 2026-04-05 |
| `feedback_karpathy_wiki_rejected.md` | Karpathy Wiki — уже пробовали и отключили 14.04 (80% дубль memory). НЕ возвращаться без новой проблемы |
| `project_hr_generator_med.md` | HR-генератор вакансий для медклиник — GO, тест Творим, деплой отложен |
| `lessons-chartjs.md` | Chart.js + maintainAspectRatio:false = ОБЯЗАТЕЛЕН position:relative контейнер, иначе canvas 6000+px |
| `feedback_kp_meeting_funnel.md` | КП = входной билет на встречу, не продажа. Анализ 60-70%, остальное на переговорах |
| `feedback_ops_is_crm.md` | artvision-data = CRM всех задач. PROJECTS.md + TODO.md + Asana + /combine — единый реестр |
| `feedback_task_propagation.md` | Задачи из Bot Dev/DevOps/Home сессий дублируются в artvision-data TODO с тегом [session:X] |
| `feedback_njus_extru_not_artvision.md` | njus.extru-tech@mail.ru = почта заказчика extru-tech-tpk. НЕ Artvision. Забыть навсегда как часть Artvision |
| `feedback_transcription_pipeline.md` | Транскрибация: Groq API или phase0_pipeline.py, НИКОГДА локальный whisper. Инцидент 13.04 с Киселевым |
| `feedback_taskcreate_always.md` | TaskCreate ВСЕГДА по умолчанию — любая задача из разговора/TODO/meeting/summary → СРАЗУ TaskCreate, без напоминания |
| `feedback_show_anton_first.md` | ВСЕГДА показывать Антону до любой отправки наружу — деплой на ревью ОК, но не "отправляем?" в том же ответе |
| `feedback_baburov_framing.md` | Бабуров/presale: НЕ "безвозмездное", НЕ "сделка" — "пилотный период", "формат сотрудничества", "рамочный договор" |
| `feedback_hide_andrey_tasks.md` | Задачи Андрея ПОКАЗЫВАТЬ + Claude автоматом напоминает в TG: без дедлайна → запрос даты, просрочено → новый срок |
| `feedback_geo_methodology_is_artvision.md` | GEO-методология = Artvision Radar, не AdvertMed. В КП через AdvertMed не палить бренд Artvision |
| `client_domains_correct.md` | tvorim-sovershenstvo.ru — НЕ ИХ домен (правильно: tvorimsovershenstvo.ru). Mirulidi = presale, не активный |
| `client_domain_avtoworld.md` | Домен avto.world (с точкой, НЕ avtoworld.ru). Папка clients/avtoworld/ — историческое |
| `feedback_verify_domains_before_smoke.md` | ОБЯЗАТЕЛЬНО сверять домен клиента с memory ПЕРЕД smoke/audit/crawl — 3 ошибки за сессию 2026-04-17 |
| `feedback_grep_existing_first.md` | ОБЯЗАТЕЛЬНО `grep -ril` по clients/ + presales/ ПЕРЕД созданием любого блока КП с нуля |
| `project_unified_automation_2026-04-15.md` | Мета-проект 15.04: TG story outreach + Contact Graph + Dashboard + AI Advisor revival, дедлайн 19-20.04, hardening AI Advisor |
| `reference_screaming_frog_cli.md` | `sf` CLI wrapper (`~/.local/bin/sf`) + хук `seo-use-sf-reminder.sh`. Setup на новой машине: `~/claude-code-settings/scripts/install-sf-wrapper.sh` |
| `reference_design_system_compact.md` | Эталон дизайн-системы "compact" — компактные шрифты, графика этапов. Склонировать с m-1-15 premium. Ростер дизайн-систем начат |
| `reference_elama_partnership.md` | eLama партнёрка: факты, подводные камни, коллтрекинг (Callibri от 20К, Calltracking.ru от 100К), Jivo/Talk-me, питч для клиентов |
| `tvorim_irina_admin.md` | Ирина = админ клиники Творим Совершенство (не пациент). Получает ВСЕ уведомления @tvorim_opros_bot. Ждём её /getid для chat_id |
| `trend_claude_code_best_practices.md` | Anthropic best practices Claude Code — verification first, short CLAUDE.md, hooks > prompts |
| `trend_autoresearch_karpathy.md` | AutoResearch Karpathy (7.03.2026, 53.5k⭐) — автономные ML-эксперименты. Применимо: лендинги, cold outreach, Claude skills |
| `reference_avportal_bot_runtime.md` | @avportal_bot живёт на VPS (grammY+polling), не Vercel. Деплой: git pull + pm2 restart |

## Orphans (добавлены автоматически — 2026-04-17 12:49)

| Файл | Содержимое |
|------|-----------|
| `feedback_factcheck_before_deploy_always.md` | АВТОМАТИЧЕСКИЙ факчекинг ПЕРЕД каждым деплоем КП — не ждать команды пользователя |
| `feedback_marketing_digest_naming.md` | Жёсткие правила публикации новостей на artvision.pro — название "Маркетинг-дайджест", своя страница на каждую новость, н |
| `feedback_no_gimmicks_in_dashboards.md` | Клиентские дашборды = серьёзная аналитика, без маркетинговых трюков (тикающие счётчики, FOMO) |
| `feedback_no_learning_logs.md` | Never show continuous-learning evaluate-session output in chat — Антон не хочет видеть эти логи |
| `feedback_search_before_build.md` | Правило "ресёрч ГОТОВЫХ решений ПЕРВЫМ" для любой задачи стандартной категории — избежать написания с нуля того что давн |
| `feedback_unotrans_spelling.md` | Правильное написание клиента — Unotrans. НЕ "UNO Trans", НЕ "UNOtrans", НЕ "Uno Trans" |
| `project_voice_control.md` | Выбранная архитектура голосового управления Claude Code — wake word + STT + алиасы |
| `reference_tg_channels.md` | Рабочие TG-каналы по получателям — кому куда писать, где DM не работает, fallback через team chat |
